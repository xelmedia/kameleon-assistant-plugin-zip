=== Zilch Assistant Plugin ===
Version: 1.4.4
Contributors: zilchuser
Tags: zilch, headless CMS, static site, manifest, auth0
Requires at least: 6.3
Tested up to: 6.6.1
Requires PHP: 8.1
Stable tag: trunk
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

WordPress plugin for managing Zilch websites, using headless CMS features and static content deployment.

== Description ==

The Zilch Assistant Plugin facilitates the deployment and management of Zilch websites within a WordPress environment. This plugin automates the provisioning of the manifest file and supports the upload of static site content. It is designed to be used with WordPress as a headless CMS, leveraging the WP REST API and GraphQL API for content management and static site generation.

Key features:
* Automatic provisioning of the manifest file.
* Support for uploading static content in chunks.
* Integration with Auth0 for secure authentication.

== Installation ==

1. Upload the plugin files to the `/wp-content/plugins/zilch-assistant` directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress.
3. Ensure the required PHP extensions are installed: `curl`, `zip`, `dom`, `libxml`, `sockets`.
4. Set the necessary PHP configuration values:
    - `MAX_EXECUTION_TIME=30`
    - `MAX_INPUT_TIME=30`
    - `UPLOAD_MAX_FILESIZE=20M`
    - `POST_MAX_SIZE=20M`
5. Configure the Zilch-specific options in the WordPress admin under `Menu -> Zilch Assistant`.

== Frequently Asked Questions ==

= What is the Zilch Assistant Plugin? =

The Zilch Assistant Plugin is designed to manage Zilch websites deployed to a WordPress environment. It automates the provisioning of the manifest file and supports the upload of static site content.

= How do I upload static content? =

Static content can be uploaded in chunks using the `/?rest_route=/assistant/static-content/upload` endpoint. After uploading all chunks, finalize the deployment by calling `/?rest_route=/assistant/static-content/deploy`.

= How does the Auth0 integration work? =

When the `wordpress/auth0` plugin is installed, the Zilch Assistant Plugin will control Auth0 authentication. This ensures secure login and management of authentication states during the provisioning process.

== Screenshots ==

1. Main settings page of the plugin (header).
2. Main settings page of the plugin (footer).
3. Loading state.

== Changelog ==

= 1.0.0 =
* Initial release of the Zilch Assistant Plugin.

== Upgrade Notice ==

= 1.0.0 =
* Initial release of the Zilch Assistant Plugin. Please configure the necessary options and ensure required PHP extensions are installed.

== License ==

This plugin is licensed under the GPLv2 or later. For more information, see [https://www.gnu.org/licenses/gpl-2.0.html](https://www.gnu.org/licenses/gpl-2.0.html).

== Additional Documentation ==

For more detailed documentation and setup instructions, please visit [Zilch Assistant Plugin Documentation](#).

