<?php
/**
 * Plugin Name: Zilch Assistant
 * Plugin URI: zi.ch
 * Description: WordPress plugin for managing Zilch websites
 * Version: 1.4.4
 * Author: xel
 * Author URI: https://xel.nl
 * License: GPLv2 or later
 * Requires Plugins: contact-form-7, wp-graphql, wp-gatsby
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 **/
declare(strict_types=1);

require __DIR__ . "/vendor/autoload.php";
require __DIR__ . "/src/assets/php/autoload.php";

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

const zilch_plugin_root_dir = __DIR__;
const zilch_plugin_index_script = __FILE__;

$wpRoot = substr(zilch_plugin_root_dir, 0, strpos(zilch_plugin_root_dir, "/wp-content"));
$wpRoot = preg_replace('/\/cms\/?$/', '', $wpRoot);
global $zilch_wp_root;
$zilch_wp_root = $wpRoot;

global $zilch_static_content_dir;
$zilch_static_content_dir = "$wpRoot/public_html";

const zilch_manifest_path = __DIR__ . '/build/assets';

use Zilch\Assistant\Register\Register_Permalink;
use Zilch\Assistant\Register\Register_Graphql;
use Zilch\Assistant\Register\Register_Meta;
use Zilch\Assistant\Register\Register_Pages_And_Blocks;
use Zilch\Assistant\Register\Register_Post_Types;
use Zilch\Assistant\Register\Register_Rest_Routes;
use Zilch\Assistant\Register\Register_Settings;
use Zilch\Assistant\Register\Register_Style_Editor;
use Zilch\Assistant\Register\Register_Svg_Support;
use Zilch\Assistant\Register\Register_Activation_Hooks;

Register_Permalink::register();
Register_Rest_Routes::register();
Register_Meta::register();
Register_Graphql::register();
Register_Style_Editor::register();
Register_Pages_And_Blocks::register();
Register_Post_Types::register();
Register_Settings::register();
Register_Svg_Support::register();
Register_Activation_Hooks::register();
