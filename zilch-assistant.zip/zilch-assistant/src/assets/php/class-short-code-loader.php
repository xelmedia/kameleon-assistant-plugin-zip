<?php
/**
 * WP Shortcode content loader
 *
 * @package Zilch Assistant
 */

declare(strict_types=1);

namespace Zilch\Assistant;

use Exception;

/**
 * Loads raw HTML content of registered WP-shortcodes.
 */
class Short_Code_Loader {

	/**
	 * Loads Contact Form 7 HTML content of a given form_id that is registered in WP.
	 *
	 * @param string $form_id The contact_form_7 the resolve the HTML content for using the shortcode tag.
	 * @throws Exception When loading fails.
	 */
	public function load_contact_form_7( string $form_id ) {
		return do_shortcode( '[contact-form-7 id="' . esc_attr( $form_id ) . '"]' );
	}
}
