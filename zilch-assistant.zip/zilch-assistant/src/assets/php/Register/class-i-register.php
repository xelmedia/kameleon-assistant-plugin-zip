<?php
/**
 * Bootstrap interface for registering actions to the WordPress core.
 *
 * @package Zilch Assistant
 */

declare(strict_types=1);

namespace Zilch\Assistant\Register;

interface I_Register {
	/**
	 * Register function to be called when bootstrapping. All classes implementing this interface should
	 * have a register function to bootstrap and hook functions to the WordPress core actions.
	 *
	 * @return void
	 */
	public static function register(): void;
}
