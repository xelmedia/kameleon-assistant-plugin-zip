<?php
/**
 * Bootstrapping for Registering Pages and Block scripts (Client Side) for use within the Block Editor.
 *
 * @package Zilch Assistant
 */

declare(strict_types=1);

namespace Zilch\Assistant\Register;

use Exception;

/**
 * Register Pages and Block scripts within the Register function, which will be called when bootstrapping the plugin.
 */
class Register_Pages_And_Blocks implements I_Register {
	public const REGISTER_BLOCKS_SCRIPT = 'register-blocks';
	public const REGISTER_BLOCKS_HANDLE = 'kameleon-assistant-' . self::REGISTER_BLOCKS_SCRIPT;

	public const INIT_BLOCK_EDITOR_SCRIPT = 'init-block-editor';
	public const INIT_BLOCK_EDITOR_HANDLE = 'kameleon-assistant-' . self::INIT_BLOCK_EDITOR_SCRIPT;

	public const REGISTER_PAGES_SCRIPT = 'register-pages';
	public const REGISTER_PAGES_HANDLE = 'kameleon-assistant-' . self::REGISTER_PAGES_SCRIPT;

	/**
	 * Register WP-core actions.
	 *
	 * @return void
	 */
	public static function register(): void {
		add_action( 'admin_init', array( __CLASS__, 'kameleon_assistant_enqueue_register_blocks' ) );

		add_action( 'enqueue_block_editor_assets', array( __CLASS__, 'kameleon_assistant_enqueue_init_block_editor' ) );

		// Page registration from manifest hook. Will be loaded using JS implementation (client site).
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'kameleon_assistant_enqueue_register_pages' ) );
		add_action( 'admin_head', array( __CLASS__, 'enqueue_and_add_inline_script' ) );
	}

	/**
	 * Enqueues the block-editor scripts within the WordPress admin-area.
	 *
	 * @return void
	 */
	public static function kameleon_assistant_enqueue_init_block_editor() {
		self::kameleon_assistant_register_script(
			self::INIT_BLOCK_EDITOR_SCRIPT,
			self::INIT_BLOCK_EDITOR_HANDLE,
			array( self::REGISTER_BLOCKS_HANDLE )
		);
	}

	/**
	 * Adding inline JS script for zilch settings that need to be used in the front-end
	 *
	 * @return void
	 */
	public static function enqueue_and_add_inline_script() {
		global $post;
		$settings = apply_filters( 'block_editor_settings_all', array(), $post );

		wp_add_inline_script( 'wp-editor', 'window.getZilchEditorSettings = ' . wp_json_encode( $settings ) . ';' );
	}

	/**
	 * Enqueues the register_pages scripts within the WordPress admin-area.
	 *
	 * @return void
	 * @throws Exception When enqueueing script fails.
	 */
	public static function kameleon_assistant_enqueue_register_pages() {
		$screen = get_current_screen();
		if ( $screen && ( 'edit' === $screen->base && 'page' === $screen->post_type ) ) {
			self::kameleon_assistant_register_script(
				self::REGISTER_PAGES_SCRIPT,
				self::REGISTER_PAGES_HANDLE,
				array( 'wp-api', self::REGISTER_BLOCKS_HANDLE )
			);
		}
	}

	/**
	 * Enqueues the block type registration scripts, to recognize custom block types.
	 *
	 * @return void
	 * @throws Exception When enqueueing script fails.
	 */
	public static function kameleon_assistant_enqueue_register_blocks() {
		self::kameleon_assistant_register_script(
			self::REGISTER_BLOCKS_SCRIPT,
			self::REGISTER_BLOCKS_HANDLE,
			array( 'wp-api', 'wp-blocks', 'wp-element', 'wp-editor', 'wp-data' )
		);
	}

	/**
	 * Returns the absolute plugin path that is accessible from the browser.
	 *
	 * @return string
	 */
	public static function plugin_uri() {
		return plugins_url( '/', zilch_plugin_index_script );
	}

	/**
	 * Generic method for registering scripts from the assets directory.
	 *
	 * @param string $script_name The script name to enqueue.
	 * @param string $script_handle The script handle.
	 * @param array  $dependencies The dependencies the given script depends on to be loaded.
	 * @return void
	 */
	public static function kameleon_assistant_register_script( string $script_name, string $script_handle, array $dependencies = array() ) {
		if ( file_exists( zilch_plugin_root_dir . "/build/$script_name.asset.php" ) ) {
			$script_dependencies = require zilch_plugin_root_dir . "/build/$script_name.asset.php";
		}

		$script_dependencies['dependencies'] = array_merge( $dependencies, $script_dependencies['dependencies'] ?? array() );

		wp_register_script(
			$script_handle,
			plugins_url( "build/$script_name.js", zilch_plugin_index_script ),
			$script_dependencies['dependencies'],
			$script_dependencies['version'],
			true
		);

		wp_enqueue_script( $script_handle );
	}
}
