<?php
/**
 * Bootstrapping for registering style editor scripts.
 *
 * @package Zilch Assistant
 */

declare(strict_types=1);

namespace Zilch\Assistant\Register;

use Zilch\Assistant\Zilch_Options;

/**
 * Register style editor scripts to hide/disable certain UI elements within the WordPress Admin Area
 */
class Register_Style_Editor implements I_Register {

	/**
	 * Register WP-core actions.
	 *
	 * @return void
	 */
	public static function register(): void {
		add_action( 'admin_init', array( __CLASS__, 'redirect_to_dashboard' ) );
		add_action( 'admin_menu', array( __CLASS__, 'remove_add_new_page_submenu' ) );
		add_action( 'wp_before_admin_bar_render', array( __CLASS__, 'remove_new_page_from_dropdown' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'general_custom_style' ) );
		add_action( 'admin_menu', array( __CLASS__, 'remove_appearance_menu' ) );
		add_filter( 'block_editor_settings_all', array( __CLASS__, 'block_editor_settings' ) );

		add_filter( 'page_row_actions', array( __CLASS__, 'remove_row_actions_page' ), 10, 1 );
		add_filter( 'bulk_actions-edit-page', array( __CLASS__, 'remove_trash_from_bulk_actions' ) );
	}

	/**
	 * Applies the style that is defined in the css file.
	 *
	 * @return void
	 */
	public static function general_custom_style(): void {
		$css_file = basename( zilch_plugin_root_dir ) . '/build/zilch-reset.css';
		wp_enqueue_style( 'zilch-reset-style', plugins_url( $css_file ) );
	}

	/**
	 * Applies default editor settings with PHP
	 *
	 * @param array $settings editor settings of gutenberg.
	 *
	 * @return array
	 */
	public static function block_editor_settings( array $settings ): array {
		$manifest = json_decode( Register_Rest_Routes::get_manifest() );

		$settings['codeEditingEnabled']    = false;
		$settings['templateLock']          = 'insert';
		$settings['scrollToBlockOnSelect'] = false;
		$settings['pluginUrl']             = Register_Pages_And_Blocks::plugin_uri();
		$settings['zilchIconPack']         = $manifest->global->theme->fonts->icons ?? '';

		return $settings;
	}

	/**
	 * Redirect the user to dashboard when post page url is entered.
	 */
	public static function redirect_to_dashboard(): void {
		global $pagenow;
		if ( ( 'post-new.php' === $pagenow &&
				isset( $_GET['post_type'] ) && 'page' === $_GET['post_type'] )
			|| 'site-editor.php' === $pagenow ) {
			wp_safe_redirect( admin_url( 'index.php' ) );
			exit;
		}
	}

	/**
	 * Remove page button from the dropdown menu.
	 *
	 * @return void
	 */
	public static function remove_new_page_from_dropdown(): void {
		global $wp_admin_bar;
		$wp_admin_bar->remove_menu( 'new-page' );
	}

	/**
	 * Remove the add new page button from the side bar (pages) vertical dropdown menu.
	 *
	 * @return void
	 */
	public static function remove_add_new_page_submenu(): void {
		global $submenu;
		if ( isset( $submenu['edit.php?post_type=page'] ) ) {
			foreach ( $submenu['edit.php?post_type=page'] as $key => $item ) {
				if ( 'post-new.php?post_type=page' === $item[2] ) {
					unset( $submenu['edit.php?post_type=page'][ $key ] );
					break;
				}
			}
		}
	}

	/**
	 * Removes the appearance tab from the menu
	 *
	 * @return void
	 */
	public static function remove_appearance_menu(): void {
		remove_menu_page( 'themes.php' );
		add_menu_page(
			__( 'Menus', Zilch_Options::TEXT_DOMAIN ), // phpcs:ignore
			__( 'Menus', Zilch_Options::TEXT_DOMAIN ), // phpcs:ignore
			'edit_theme_options',
			'nav-menus.php',
			'',
			'dashicons-menu',
			61
		);
	}

	/**
	 *  It will remove the actions from the rows in the edit pages!
	 *
	 * @param mixed $actions Default actions to be returned if criteria not met.
	 * @return mixed|void
	 */
	public static function remove_row_actions_page( $actions ) {
		unset( $actions['trash'] );
		unset( $actions['view'] );

		return $actions;
	}

	/**
	 * It will remove the move to trash option from the bulk actions in the edit pages!
	 *
	 * @param mixed $actions Default actions to be filtered when criteria is met.
	 **/
	public static function remove_trash_from_bulk_actions( $actions ) {
		if ( is_array( $actions ) && isset( $actions['trash'] ) ) {
			unset( $actions['trash'] );
		}
		return $actions;
	}
}
