<?php
/**
 * Bootstrapping for Registering `Post\Page` meta attributes.
 *
 * @package Zilch Assistant
 */

declare(strict_types=1);

namespace Zilch\Assistant\Register;

use Exception;
use Zilch\Assistant\Clients\Zilch\Domain\Build_Site_Request;
use Zilch\Assistant\Clients\Zilch\Zilch_Gateway_Client;
use Zilch\Assistant\Alerting\Alert_Renderer;
use Zilch\Assistant\Zilch_Options;

/**
 * Register post meta types, which can be used to store custom additional post meta attribute values.
 */
class Register_Meta implements I_Register {
	const META_KEY_KAMELEON_PAGE_ID   = 'kameleon_page_id';
	const META_KEY_SKIP_BUILD_TRIGGER = 'skip_build_trigger';

	/**
	 * Register WP-core actions.
	 *
	 * @return void
	 */
	public static function register(): void {
		register_meta(
			'post',
			self::META_KEY_KAMELEON_PAGE_ID,
			array(
				'type'         => 'string',
				'description'  => 'The kameleon page id',
				'single'       => true,
				'show_in_rest' => true,
			)
		);

		register_meta(
			'post',
			self::META_KEY_SKIP_BUILD_TRIGGER,
			array(
				'type'         => 'boolean',
				'description'  => 'Indicated whether the build should be skipped upon save',
				'single'       => true,
				'show_in_rest' => true,
			)
		);

		add_action( 'admin_bar_menu', array( __CLASS__, 'add_zilch_publish_item' ), 999, 2 );
		add_action( 'wp_after_insert_post', array( __CLASS__, 'set_save_success_alert' ), 10, 2 );
	}

	/**
	 * Sets a success alert within Gutenberg that content is saved.
	 *
	 * @return void
	 */
	public static function set_save_success_alert(): void {
		Alert_Renderer::set_success(
			'Je wijzigingen zijn opgeslagen! Ben je klaar bent met het maken van wijzigingen? Dan kun je deze ' .
			'direct ' . static::html_js_publish_trigger( 'publiceren!' )
		);
	}

	/**
	 * Inline clickable link that will trigger the publish site action.
	 *
	 * @param string $txt Link text.
	 * @return string
	 */
	private static function html_js_publish_trigger( string $txt ): string {
		return '<a onclick="(function(){
            publishSite?.()
            return false;
        })();return false;" href="#">' . $txt . '</a>';
	}

	/**
	 * Handle to trigger a Zilch site build by use of the external Zilch Gateway API.
	 * This action occurs only when publish is triggered by user.
	 *
	 * @return \WP_Error|null
	 */
	public static function kameleon_assistant_trigger_build() {
		try {
			$gateway_client = Zilch_Gateway_Client::instance();
			$ip_address     = isset( $_SERVER['SERVER_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['SERVER_ADDR'] ) ) : null;
			if ( ! $ip_address ) {
				return new \WP_Error( 500, 'The ip address of the server is not set' );
			}
			$gateway_client->build_site( new Build_Site_Request( Zilch_Options::get_site_host(), $ip_address ) );
		} catch ( \Throwable $t ) {
			Alert_Renderer::set_error(
				'Er is een fout opgetreden bij het publiceren van nieuw opgeslagen content. ' .
				'Geen zorgen, er is geen data verlies. ' . static::html_js_publish_trigger( 'Probeer opnieuw.' ),
				$t
			);
		}
	}

	/**
	 * Add a publish menu bar item to publish site changes.
	 *
	 * @param mixed $admin_bar The admin bar api.
	 * @throws Exception On unknown error.
	 */
	public static function add_zilch_publish_item( $admin_bar ): void {
		$admin_bar->add_menu(
			array(
				'id'    => 'zilch-build-site',
				'title' => '
<span class="zilch-admin__menu-icon">
    <img alt="zilch_icon" src="' . Register_Pages_And_Blocks::plugin_uri() . 'build/assets/kameleon-logo-static.png"/>
</span>' . __( 'Publish' ),
				'href'  => '#',
				'meta'  => array(
					'id' => 'zilch-build-site',
				),
			)
		);
	}
}
