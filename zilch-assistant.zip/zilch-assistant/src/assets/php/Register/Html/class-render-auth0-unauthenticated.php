<?php
/**
 * Auth0 unauthenticated renderer interface.
 *
 * @package Zilch Assistant
 */

declare(strict_types=1);

namespace Zilch\Assistant\Register\Html;

use Exception;

/**
 * Renderer class.
 */
class Render_Auth0_Unauthenticated {


	/**
	 * Returns HTML that will display access denied.
	 *
	 * @return string
	 */
	public static function render(): string {
		$site_url = get_site_url();
		return ( '
            <!DOCTYPE html>
            <html lang="nl">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>Toegang Geweigerd</title>
                <style>
                    @import url("https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&display=swap");
                    
                    body {
                        font-family: "Poppins", sans-serif;
                        background-color: #f7f8fa;
                        color: #333;
                        margin: 0;
                        padding: 0;
                        display: flex;
                        justify-content: center;
                        align-items: center;
                        height: 100vh;
                        font-size: 16px;
                    }
                    .container {
                        background-color: #ffffff;
                        padding: 40px;
                        border-radius: 16px;
                        box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
                        text-align: center;
                        max-width: 550px;
                        width: 100%;
                        animation: fadeIn 1s ease-out;
                    }
                    h1 {
                        color: #8a2be2; /* Paars van Zilch */
                        font-size: 28px;
                        font-weight: 600;
                        margin-bottom: 20px;
                    }
                    p {
                        font-size: 16px;
                        line-height: 1.7;
                        margin-bottom: 20px;
                        color: #555;
                    }
                    a {
                        display: inline-block;
                        padding: 12px 30px;
                        background-color: #8a2be2; /* Paars van Zilch */
                        color: #ffffff;
                        text-decoration: none;
                        font-weight: 500;
                        border-radius: 8px;
                        transition: background-color 0.3s ease;
                        box-shadow: 0 4px 15px rgba(138, 43, 226, 0.3);
                    }
                    a:hover {
                        background-color: #6d23b9; /* Donkerdere paars bij hover */
                        box-shadow: 0 6px 20px rgba(138, 43, 226, 0.4);
                    }
                    @keyframes fadeIn {
                        from {
                            opacity: 0;
                            transform: translateY(20px);
                        }
                        to {
                            opacity: 1;
                            transform: translateY(0);
                        }
                    }
                </style>
            </head>
            <body>
                <div class="container">
                    <h1>Toegang Geweigerd</h1>
                    <p>De gebruiker is niet gemachtigd om in te loggen op <strong>' . esc_html( $site_url ) . '</strong>, of er is een andere authenticatiefout opgetreden.</p>
                    <p>Zorg ervoor dat je dezelfde authenticatiemethode en login gegevens gebruikt als in de <strong>Zilch App</strong> om verder te gaan.</p>
                    <p><a href="/wp-login.php?action=logout">Uitloggen</a></p>
                </div>
            </body>
            </html>' );
	}
}
