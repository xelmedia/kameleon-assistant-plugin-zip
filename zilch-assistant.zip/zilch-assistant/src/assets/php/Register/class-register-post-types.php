<?php
/**
 * Bootstrapping for Registering custom Post Types
 *
 * @package Zilch Assistant
 */

declare(strict_types=1);

namespace Zilch\Assistant\Register;

/**
 * Register custom post types like `Header` and `Footer`
 */
class Register_Post_Types implements I_Register {

	/**
	 * Register WP-core actions.
	 *
	 * @return void
	 */
	public static function register(): void {
		add_action( 'init', array( __CLASS__, 'register_post_types' ) );
		add_action( 'rest_api_init', array( __CLASS__, 'register_rest_field' ) );
	}

	/**
	 *
	 * Return custom term fields in rest api requests
	 *
	 * @return void
	 */
	public static function register_rest_field(): void {
		register_rest_field(
			'zilch_header',
			'kameleon_page_id',
			array(
				'get_callback'    => function ( $post, $field_name, $request ) {
					return get_post_meta( $post['id'], $field_name, true );
				},
				'update_callback' => null,
				'schema'          => null,
			)
		);
	}

	/**
	 * Register Posttypes for zilch
	 *
	 * @return void
	 */
	public static function register_post_types(): void {
		register_post_type(
			'zilch_header',
			array(
				'label'               => 'Header',
				'public'              => false,
				'publicly_queryable'  => true,
				'rewrite'             => array( 'slug' => 'header' ),
				'has_archive'         => false,
				'show_in_rest'        => true,
				'show_in_menu'        => false,
				'show_ui'             => false,
				'template_lock'       => true,
				'supports'            => array( 'title', 'editor', 'custom-fields' ),
				'show_in_graphql'     => true,
				'graphql_single_name' => 'zilchHeader',
				'graphql_plural_name' => 'zilchHeaders',
			)
		);
		register_post_type(
			'zilch_footer',
			array(
				'label'               => 'Footer',
				'public'              => false,
				'publicly_queryable'  => true,
				'rewrite'             => array( 'slug' => 'footer' ),
				'has_archive'         => false,
				'show_in_rest'        => true,
				'show_in_menu'        => false,
				'show_ui'             => false,
				'template_lock'       => true,
				'supports'            => array( 'title', 'editor', 'custom-fields' ),
				'show_in_graphql'     => true,
				'graphql_single_name' => 'zilchFooter',
				'graphql_plural_name' => 'zilchFooters',
			)
		);
	}
}
