<?php
/**
 * Zilch Settings page
 *
 * @package Zilch Assistant
 */

declare( strict_types=1 );

namespace Zilch\Assistant\Register;

/**
 * Register the Zilch Settings page class helper.
 */
class Register_Settings implements I_Register {

	/**
	 * Register WP-core actions.
	 *
	 * @return void
	 */
	public static function register(): void {
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_kameleon_scripts' ) );
		add_action( 'admin_menu', array( __CLASS__, 'add_settings_page' ) );
		add_action( 'admin_head', array( __CLASS__, 'disable_inserter_toggle' ), 10, 2 );

		add_theme_support( 'menus' );
		self::register_zilch_settings();
	}


	/**
	 * Register WordPress option settings for zilch.
	 *
	 * @return void
	 */
	public static function register_zilch_settings() {
		register_setting(
			'zilch',
			'zilch_profile',
			array(
				'type'              => 'string',
				'sanitize_callback' => 'sanitize_text_field',
				'default'           => null,
				'show_in_graphql'   => true,
			)
		);

		register_setting(
			'zilch',
			'zilch_theme',
			array(
				'type'              => 'string',
				'sanitize_callback' => 'sanitize_text_field',
				'default'           => null,
				'show_in_graphql'   => true,
			)
		);

		register_setting(
			'zilch',
			'zilch_manifest_id',
			array(
				'type'              => 'string',
				'sanitize_callback' => null,
				'default'           => null,
				'show_in_rest'      => true,
			)
		);
	}

	/**
	 * Enqueue scripts and styles for the admin area.
	 *
	 * @param string $hook the hook of the loaded page.
	 */
	public static function enqueue_kameleon_scripts( string $hook ) {
		if ( in_array( $hook, array( 'settings_page_zilch_header', 'settings_page_zilch_footer' ) ) ) {
			wp_enqueue_style( 'wp-edit-blocks' );

			Register_Pages_And_Blocks::kameleon_assistant_register_script(
				Register_Pages_And_Blocks::REGISTER_PAGES_SCRIPT,
				Register_Pages_And_Blocks::REGISTER_PAGES_HANDLE,
				array( Register_Pages_And_Blocks::REGISTER_BLOCKS_HANDLE )
			);

			Register_Pages_And_Blocks::kameleon_assistant_register_script(
				'settings-page',
				'zilch-settings',
				array( Register_Pages_And_Blocks::REGISTER_PAGES_HANDLE )
			);

			\WPGraphQLGutenberg\Admin\Editor::enqueue_script();

		}

		wp_enqueue_style(
			'zich-global-admin-style',
			plugins_url( 'build/global-admin-style.css', zilch_plugin_index_script ),
			array(),
			filemtime( dirname( zilch_plugin_index_script ) . '/build/global-admin-style.css' )
		);
		Register_Pages_And_Blocks::kameleon_assistant_register_script( 'global-admin', 'zilch-global-scripts' );
	}

	/**
	 * Adding the zilch settings page
	 */
	public static function add_settings_page() {
		add_options_page(
			'zilch-settings',
			'Header',
			'edit_posts',
			'zilch_header',
			array( __CLASS__, 'render_settings_page' ),
		);

		add_options_page(
			'zilch-settings',
			'Footer',
			'edit_posts',
			'zilch_footer',
			array( __CLASS__, 'render_settings_page' ),
		);
	}

	/**
	 * Adding empty div for ReactJS
	 */
	public static function render_settings_page() {
		echo '<div id="editor" class="block-editor__container"></div>';
	}


	/**
	 * Disable insert for specific post type
	 */
	public static function disable_inserter_toggle() {
		global $post;

		if ( isset( $post->post_type ) && 'page' === $post->post_type ) {
			echo '<style>
            .editor-document-tools__inserter-toggle {
                display: none !important;
            }
        </style>';
		}
	}
}
