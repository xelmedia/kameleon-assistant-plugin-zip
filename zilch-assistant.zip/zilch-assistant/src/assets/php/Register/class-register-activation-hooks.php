<?php
/**
 * Bootstrapping for Registering hooks upon plugin activation.
 *
 * @package Zilch Assistant
 */

declare(strict_types=1);

namespace Zilch\Assistant\Register;

/**
 * Activation hooks class to enforce certain settings for Zilch sites within the WP environment.
 */
class Register_Activation_Hooks implements I_Register {

	/**
	 * Register WP-core actions.
	 *
	 * @return void
	 */
	public static function register(): void {
		// Hook to run the function upon plugin activation.
		register_activation_hook( zilch_plugin_index_script, array( __CLASS__, 'set_permalink_structure_on_init' ) );
		add_action( 'admin_init', array( __CLASS__, 'set_permalink_structure' ) );
	}

	/**
	 * Enforce the '/%postname%/' permalink structure upon activation.
	 * Flushes the rules and ensure correct write-off to the .htaccess.
	 *
	 * @return void
	 */
	public static function set_permalink_structure(): void {
		if ( get_option( 'set_permalink_structure' ) ) {
			delete_option( 'set_permalink_structure' );
		} else {
			return;
		}

		// Check if the current permalink structure is already /%postname%/ to avoid unnecessary operations.
		update_option( 'permalink_structure', '/%postname%/' );
		update_option( 'rewrite_rules', false );
		flush_rewrite_rules();
		save_mod_rewrite_rules( true );
	}

	/**
	 * Enforce permalink structure to be set on init, because WP-CLI environment not always has mod_rewrite module
	 * activated, thus the write-off to a .htaccess file would not be ensured.
	 *
	 * We set a wp_option that will be read upon admin_init hook (accessed from webbrowser). If set, the write-off will
	 * be done.
	 *
	 * @return void
	 */
	public static function set_permalink_structure_on_init() {
		update_option( 'set_permalink_structure', 1, true );
	}
}
