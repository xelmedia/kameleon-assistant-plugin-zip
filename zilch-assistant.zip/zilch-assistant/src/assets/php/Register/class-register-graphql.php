<?php
/**
 * Bootstrapping for Registering GraphQL hooks.
 *
 * @package Zilch Assistant
 */

declare(strict_types=1);

namespace Zilch\Assistant\Register;

use Exception;
use Zilch\Assistant\Contact_Form_7;
use Zilch\Assistant\Graphql;
use Zilch\Assistant\Graphql_Block_Info;
use Zilch\Assistant\Short_Code_Loader;

/**
 * Register hooks to transform GraphQL output
 */
class Register_Graphql implements I_Register {

	/**
	 * Register WP-core actions.
	 *
	 * @return void
	 * @throws Exception When initialisation fails.
	 */
	public static function register(): void {
		add_filter(
			'graphql_request_results',
			function ( $response ) {
				if ( isset( $response->data ) && is_array( $response->data ) ) {
					$graphql        = new Graphql(
						$response->data,
						new Contact_Form_7( new Short_Code_Loader() ),
						new Graphql_Block_Info()
					);
					$response->data = $graphql->reformat_response_data();
				}
				return $response;
			},
			99,
			1
		);
	}
}
