<?php
/**
 * Zilch REST Routes
 *
 * @package Zilch Assistant
 */

declare(strict_types=1);

namespace Zilch\Assistant\Register;

use Throwable;
use Zilch\Assistant\Alerting\Debug_Logger;
use Zilch\Assistant\Clients\Zilch\Helpers\Zilch_Gateway_Client_Helper;
use Zilch\Assistant\Register\Html\Render_Auth0_Unauthenticated;
use Zilch\Assistant\StaticContent\Zip_Uploader;
use Zilch\Assistant\Zilch_Options;
use WP_Error;
use WP_HTTP_Response;
use WP_REST_Request;
use WP_REST_Response;

/**
 * Registration of Zilch REST API routes
 */
class Register_Rest_Routes implements I_Register {

	/**
	 * Register WP-core actions.
	 *
	 * @return void
	 */
	public static function register(): void {
		// Hook into auth0's token exchange failed action to force logout.
		add_action(
			'auth0_token_exchange_failed',
			function ( $throwable ) {
                // phpcs:disable
				echo Render_Auth0_Unauthenticated::render();
                // phpcs:enable
				if ( $throwable instanceof Throwable ) {
					Debug_Logger::log( 'Error while exchanging token: ' . $throwable->getMessage() );
				}
				exit;
			},
			1
		);

		// Important: We must force the auth0 state to be enabled upon logout and authentication.
		// @ref: `set_auth0_state`.
		add_action( 'wp_authenticate', fn() => self::set_auth0_state( true ) );
		add_action( 'wp_logout', fn() => self::set_auth0_state( true ) );
		add_action( 'rest_api_init', array( __CLASS__, 'kameleon_assistant_rest_route_init' ) );
	}

	/**
	 * Rest routes index.
	 *
	 * @return void
	 */
	public static function kameleon_assistant_rest_route_init(): void {

		register_rest_route(
			'assistant',
			'blockinfo/type/(?P<blockType>.+)',
			array(
				'methods'             => 'GET',
				'callback'            => fn( $request ) => self::find_blocks_by_type( $request->get_param( 'blockType' ) ),
				'permission_callback' => fn() => in_array( 'administrator', wp_get_current_user()->roles ),
			)
		);

		register_rest_route(
			'assistant',
			'blockinfo/(?P<packageName>.+)',
			array(
				'methods'             => 'GET',
				'callback'            => fn( $request ) => self::get_blockinfo( $request->get_param( 'packageName' ) ),
				'permission_callback' => fn() => in_array( 'administrator', wp_get_current_user()->roles ),
			)
		);

		register_rest_route(
			'assistant',
			'get-manifest',
			array(
				'methods'             => 'GET',
				'callback'            => fn() => self::get_manifest(),
				'permission_callback' => fn() => in_array( 'administrator', wp_get_current_user()->roles ),
			)
		);

		register_rest_route(
			'assistant',
			'menus',
			array(
				'methods'             => 'GET',
				'callback'            => fn() => self::get_menus(),
				'permission_callback' => fn() => in_array( 'administrator', wp_get_current_user()->roles ),
			)
		);

		register_rest_route(
			'assistant',
			'settings',
			array(
				'methods'             => 'POST',
				'callback'            => fn( $request ) => self::update_zilch_settings( $request ),
				'permission_callback' => fn() => current_user_can( 'manage_options' ),
			)
		);

		register_rest_route(
			'assistant',
			'posts/(?P<post_type>\w+)',
			array(
				'methods'             => 'GET',
				'callback'            => fn( $request ) => self::get_posts_by_type( $request ),
				'permission_callback' => fn() => in_array( 'administrator', wp_get_current_user()->roles ),
			)
		);

		register_rest_route(
			'assistant',
			'manifest',
			array(
				'methods'             => 'POST',
				'callback'            => fn( $request ) => self::post_manifest( $request ),
				'permission_callback' => fn( \WP_REST_Request $request ) => self::validate_zilch_secret( $request ),
			)
		);

		register_rest_route(
			'assistant',
			'init-manifest',
			array(
				'methods'             => 'GET',
				'callback'            => fn() => self::init_manifest(),
				'permission_callback' => fn( \WP_REST_Request $request ) => self::validate_zilch_secret( $request ),
			)
		);

		register_rest_route(
			'assistant',
			'static-content/upload',
			array(
				'methods'             => 'POST',
				'callback'            => fn( $request ) => self::static_content_upload( $request ),
				'permission_callback' => fn( \WP_REST_Request $request ) => self::validate_zilch_secret( $request ),
			)
		);

		register_rest_route(
			'assistant',
			'static-content/deploy',
			array(
				'methods'             => 'POST',
				'callback'            => fn() => self::static_content_deploy(),
				'permission_callback' => fn( \WP_REST_Request $request ) => self::validate_zilch_secret( $request ),
			)
		);

		register_rest_route(
			'assistant',
			'static-content/build',
			array(
				'methods'             => 'POST',
				'callback'            => function () {
					Register_Meta::kameleon_assistant_trigger_build();
					return new WP_REST_Response( '{}', 200 );
				},
				'permission_callback' => fn() => in_array( 'administrator', wp_get_current_user()->roles ),
			)
		);
	}

	/**
	 * Upload (from client perspective) a zip-file containing static-content to be deployed eventually.
	 * The zip-file should be provided as `octet+stream` content-type and should be limited to a size of max. 10 mb.
	 *
	 * If the file exceeds this limit, the client should upload chunks of the zip file.
	 * The client is required to provide the following request headers:
	 *
	 * - X-Zilch-Static-Content-Chunk --> Current chunk sent by the client
	 * - X-Zilch-Static-Content-Chunk-Total --> Total chunks to be sent by the client.
	 *
	 * When sending the last chunk, the client is required to provide the expected MD5 checksum of the complete zip: e.g:
	 * - X-Zilch-Static-Content-Chunk: 10
	 * - X-Zilch-Static-Content-Chunk-Total: 10
	 * - X-Zilch-Static-Content-Md5sum: md5($zip)
	 *
	 * This endpoint will verify the integrity checksum of the zipfile that was uploaded to ensure that the uploaded zip
	 * was completed successfully.
	 *
	 * NEXT, the client should execute a request to: `/assistant/static-content/deploy (POST)
	 * See: static_content_deploy.
	 *
	 * @param WP_REST_Request   $request  The client request.
	 * @param Zip_Uploader|null $uploader The zip_uploader instance. Only used within unit testing.
	 * @return WP_Error|null
	 */
	public static function static_content_upload( WP_REST_Request $request, Zip_Uploader $uploader = null ) {
		$chunk_total   = $request->get_header( 'X-Zilch-Static-Content-Chunk-Total' );
		$chunk_current = $request->get_header( 'X-Zilch-Static-Content-Chunk' );

		if ( ! $chunk_total ) {
			return new \WP_Error( 403, 'Unable to locate header: `X-Zilch-Static-Content-Chunk-Total`' );
		}
		if ( ! $chunk_current ) {
			return new WP_Error( 403, 'Unable to locate header: `X-Zilch-Static-Content-Chunk`' );
		}
		if ( ( $chunk_current > $chunk_total ) || ( $chunk_current < 1 ) ) {
			return new WP_Error( 403, "Invalid chunk number ($chunk_current) received of total ($chunk_total)" );
		}

		$chunk_total   = (int) $chunk_total;
		$chunk_current = (int) $chunk_current;

		$zip_uploader = $uploader ?? new Zip_Uploader();
		$zip_uploader->write_zip_chunk( $chunk_current );

		if ( $chunk_current === $chunk_total ) {
			$expected_md5 = $request->get_header( 'X-Zilch-Static-Content-Md5sum' );
			if ( ! $expected_md5 ) {
				return new WP_Error( 403, 'Received all chunks, but unable to locate expected md5sum' );
			}

			try {
				$zip_uploader->verify_zip( $expected_md5 );
			} catch ( \Throwable $e ) {
				return new WP_Error( 403, $e->getMessage() );
			}
		}
		return null;
	}

	/**
	 * Unzips the earlier `uploaded` zip (in route: /assistant/static-content/upload) with interruptions.
	 * Runs for a maximum time and returns a `X-Zilch-Unzip-Status: pending` header to the client as long as the unzip
	 * process is not complete yet.
	 *
	 * Also, the response headers will contain a `X-Zilch-Unzip-Remaining-Files` header containing a numeric value
	 * representing the amount of files left to be unzipped.
	 *
	 * Once unzip is completed, the static content that was unzipped will be deployed to the Website's static-content
	 * directory to be served to browser clients.
	 *
	 * @param Zip_Uploader|null $uploader The zip_uploader instance. Only used within unit testing.
	 * @throws Throwable Unexpected error.
	 * @return WP_Error|WP_REST_Response
	 */
	public static function static_content_deploy( Zip_Uploader $uploader = null ) {
		$zip_uploader = $uploader ?? new Zip_Uploader();
		try {
			$remaining_files = $zip_uploader->unzip();

			if ( $remaining_files > 0 ) {
				return new WP_REST_Response(
					null,
					200,
					array(
						'X-Zilch-Unzip-Status'          => 'pending',
						'X-Zilch-Unzip-Remaining-Files' => $remaining_files,
					)
				);
			} else {
				$zip_uploader->deploy();
				return new WP_REST_Response(
					null,
					200,
					array(
						'X-Zilch-Unzip-Status'          => 'completed',
						'X-Zilch-Unzip-Remaining-Files' => 0,
					)
				);
			}
		} catch ( Throwable $t ) {
			$msg = "Error unzipping: {$t->getMessage()}";
			Debug_Logger::log( $msg, Debug_Logger::LOG_LEVEL_ERROR );
			return new WP_Error( 500, $msg );
		}
	}

	/**
	 * Callback, which should be registered as permission hook, to validate the Zilch Client Secret within the headers.
	 * The secret will be validated against the known Zilch Client Secret for this installation.
	 *
	 * @param WP_REST_Request $request The client request.
	 * @return bool
	 */
	public static function validate_zilch_secret( $request ) {
		$header_key = 'X-Zilch-Client-Secret';

		try {
			$expected_client_secret_encoded = Zilch_Options::get_client_secret();
		} catch ( \Throwable $_ ) {
			Debug_Logger::log( 'No client secret found', Debug_Logger::LOG_LEVEL_WARNING );
			return false;
		}

		$client_secret_encoded = $request->get_header( $header_key );
		if ( ! empty( $expected_client_secret_encoded ) ) {
			if ( $client_secret_encoded === $expected_client_secret_encoded
				|| base64_encode( $client_secret_encoded ?? '' ) === $expected_client_secret_encoded ) {
				return true;
			}
		}
		Debug_Logger::log( 'Client secret mismatch', Debug_Logger::LOG_LEVEL_WARNING );
		return false;
	}

	/**
	 * Controller action for initializing newly deployed (or re-initialize existing) manifest.json definitions.
	 * Changed manifest definitions will bring changes to pages, page-order, layouts/blocks within pages,
	 * header, footer and menu's.
	 *
	 * Initialization of the manifest includes:
	 * - Validate client secret from header.
	 * - Create (if not exists) administrator user
	 * - Set administrator user authenticated
	 * - Redirect to `edit pages` overview, which triggers the JS-scripts to update page content according to manifest.
	 *
	 * @return void
	 */
	public static function init_manifest() {
		static::header( 'Content-Type: text/html' );
		$user = get_user_by( 'login', $admin_user = 'zilch-admin' );

		// Create user if not exists.
		if ( ! $user ) {
			$random_pass = substr( str_shuffle( strtolower( sha1( wp_rand() . time() . "$admin_user" ) ) ), 0, 12 );
			$user_id     = wp_create_user( $admin_user, $random_pass );
			$user        = new \WP_User( $user_id );
			$user->set_role( 'administrator' );
			$user = get_user_by( 'login', $admin_user );
		}
		wp_set_current_user( $user->ID );
		wp_set_auth_cookie( $user->ID );
		self::set_auth0_state( false );

		wp_safe_redirect( admin_url( '/edit.php?post_type=page&open_home_page=1' ) );
		static::exit();
	}

	/**
	 * Sets the auth0 state enabled/disabled. Enabling will force redirect to auth0 tenant.
	 * When disabling, this will still have the plugin itself enabled, but only the "master" switch disabled.
	 *
	 * We will force the auth0 state on logout and upon authentication, forcing auth0!
	 *
	 * In some situations we will disabled auth0, to we can programmatically login an admin user while bypassing auth0.
	 * These actions include: - init_manifest.
	 *
	 * @param bool $enable Enable/disable auth0 authentication.
	 * @return void
	 */
	public static function set_auth0_state( bool $enable ) {
		$state = get_option( 'auth0_state' ) ?? array();
		if ( ! is_array( $state ) ) {
			$state = array();
		}

		// Only set state if the state was changed.
		$is_enabled = in_array( ( $state['enable'] ?? null ), array( 1, '1', true, 'true' ), true );
		if ( $is_enabled && true === $enable ) {
			return;
		}
		if ( ! $is_enabled && false === $enable ) {
			return;
		}

		// Update the state.
		$state['enable'] = $enable ? 'true' : 'false';
		update_option( 'auth0_state', $state );

		// Only redirect to admin if auth0 was enabled, otherwise login form will be shown anyways if the state was disabled.
		// Therefor, set auth0 enabled and reload.
		if ( $enable ) {
			wp_safe_redirect( admin_url() );
		}
	}

	/**
	 * Wrapper function to terminate PHP process.
	 *
	 * @return void
	 */
	protected static function exit() {
		exit();
	}

	/**
	 * Wrapper function to set header.
	 *
	 * @param string $value The header to set.
	 * @return void
	 */
	protected static function header( string $value ) {
		header( $value );
	}

	/**
	 * Get the block info given the package name by using the gateway client
	 *
	 * @param string $package_name Package name.
	 * @return mixed|WP_Error
	 */
	public static function get_blockinfo( string $package_name ) {
		try {
			$gateway_client = Zilch_Gateway_Client_Helper::get_gateway_client_instance();
			$response       = $gateway_client->get_block_by_package_name( $package_name );
			if ( ! $response ) {
				return new WP_Error( 'blockinfo_not_found', "BlockInfo for $package_name not found", array( 'status' => 404 ) );
			}
			return json_decode( $response );
		} catch ( \Exception $e ) {
			return new WP_Error( 'blockinfo_error', "Error resolving blockInfo for $package_name:" . $e->getMessage(), array( 'status' => $e->getCode() ?? 500 ) );
		}
	}

	/**
	 * Get the block info given the block type by using the gateway client
	 *
	 * @param string $block_type blockType to check for.
	 *
	 * @return mixed|WP_Error
	 */
	public static function find_blocks_by_type( string $block_type ) {
		try {
			$gateway_client = Zilch_Gateway_Client_Helper::get_gateway_client_instance();
			$response       = $gateway_client->get_block_by_type( $block_type );
			return json_decode( $response );
		} catch ( \Exception $e ) {
			return new WP_Error( 'blockinfo_not_found', "BlockInfo with type $block_type not found", array( 'status' => 404 ) );
		}
	}

	/**
	 * Controller action for POSTing and deploying a new manifest.json file.
	 *
	 * @param WP_REST_Request $request Client request.
	 * @return WP_Error|null
	 */
	public static function post_manifest( $request ) {
		$pay_load = $request->get_body();
		$body     = json_decode( $pay_load, true );

		if ( ! isset( $body['manifestData'] ) ) {
			return new WP_Error( 'manifest_invalid_json', 'No manifestData found', array( 'status' => 400 ) );
		}

		$manifest_decoded = base64_decode( $body['manifestData'], true );
		if ( ! $manifest_decoded || ! mb_check_encoding( $manifest_decoded, 'UTF-8' ) ) {
			return new WP_Error( 'manifest_invalid_base64', 'Manifest is not base64 encoded', array( 'status' => 400 ) );
		}

		if ( ! json_decode( $manifest_decoded, true ) ) {
			return new WP_Error( 'manifest_invalid_json', 'JSON of manifest not valid', array( 'status' => 400 ) );
		}

		$manifest_saved = file_put_contents( zilch_manifest_path . '/manifest.json', $manifest_decoded );
		if ( ! $manifest_saved ) {
			return new WP_Error( 'manifest_not_saved', 'New manifest is not due and error', array( 'status' => 400 ) );
		}

		$saved_manifest = self::get_manifest();
		if ( $saved_manifest !== $manifest_decoded ) {
			return new WP_ERROR( 'manifest_not_saved', 'The given manifest could not be saved correctly', array( 'status' => 500 ) );
		}
		return null;
	}

	/**
	 * Controller action for resolving the currently deployed `manifest.json` file.
	 *
	 * @return false|string|WP_Error
	 */
	public static function get_manifest() {
		$manifest_path = zilch_manifest_path . '/manifest.json';
		if ( ! file_exists( $manifest_path ) ) {
			return new \WP_Error( 'manifest_not_found', 'Manifest not found', array( 'status' => 404 ) );
		}
		return file_get_contents( $manifest_path );
	}

	/**
	 * Controller action for getting menu's.
	 */
	public static function get_menus() {
		return wp_json_encode( wp_get_nav_menus( array( 'hide_empty' => false ) ) );
	}

	/**
	 * Controller action for editing/setting the `kameleon_settings_group` WP_Option.
	 *
	 * @param WP_REST_Request $request Client request.
	 * @return WP_Error|WP_HTTP_Response|WP_REST_Response
	 */
	public static function update_zilch_settings( $request ) {
		$settings = json_decode( $request->get_body(), true );

		if ( $settings['zilch_theme'] ?? false ) {
			update_option( 'zilch_theme', json_encode( $settings['zilch_theme'] ) );
		}

		if ( $settings['zilch_profile'] ?? false ) {
			update_option( 'zilch_profile', json_encode( $settings['zilch_profile'] ) );
		}

		if ( $settings['zilch_manifest_id'] ?? false ) {
			update_option( 'zilch_manifest_id', $settings['zilch_manifest_id'] );
		}

		return rest_ensure_response( 'Settings updated successfully' );
	}

	/**
	 * Controller action for resolving posts by type.
	 *
	 * @param WP_REST_Request $request  Client request.
	 * @return WP_Error|WP_HTTP_Response|WP_REST_Response
	 */
	public static function get_posts_by_type( WP_REST_Request $request ) {
		$post_type   = $request['post_type'];
		$meta_key    = 'kameleon_page_id';
		$kameleon_id = $request[ $meta_key ];

		$args = array(
			'post_type'      => $post_type,
			'meta_key'       => $meta_key,
			'meta_value'     => $kameleon_id,
			'posts_per_page' => -1,
		);

		$post_type_object = get_post_type_object( $post_type );
		if ( ! $post_type_object ) {
			return new WP_Error( 'rest_post_invalid_type', __( 'Invalid post type.', Zilch_Options::TEXT_DOMAIN ), array( 'status' => 404 ) ); // phpcs:ignore
		}

		$rest_controller_class = ! empty( $post_type_object->rest_controller_class ) ? $post_type_object->rest_controller_class : 'WP_REST_Posts_Controller';
		if ( ! class_exists( $rest_controller_class ) ) {
			return new WP_Error( 'rest_post_invalid_controller', __( 'Invalid REST Controller.', Zilch_Options::TEXT_DOMAIN ), array( 'status' => 404 ) ); // phpcs:ignore
		}

		$rest_controller = new $rest_controller_class( $post_type );

		$query = new \WP_Query( $args );
		$posts = array();
		foreach ( $query->posts as $post ) {
			$data    = $rest_controller->prepare_item_for_response( $post, $request )->get_data();
			$posts[] = $data;
		}
		return rest_ensure_response( $posts );
	}
}
