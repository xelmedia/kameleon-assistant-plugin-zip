<?php
/**
 * Bootstrapping for Registering the enforcement of the permalinks upon plugin activation.
 *
 * @package Zilch Assistant
 */

declare(strict_types=1);

namespace Zilch\Assistant\Register;

/**
 * Register permalink hooks.
 */
class Register_Permalink implements I_Register {

	/**
	 * Register WP-core actions.
	 *
	 * @return void
	 */
	public static function register(): void {
		register_activation_hook( zilch_plugin_index_script, array( __CLASS__, 'rewrite_permalink' ) );
	}

	/**
	 * Rewrite the permalink structure to /%postname%
	 *
	 * @return void
	 */
	public static function rewrite_permalink() {
		global $wp_rewrite;
		$wp_rewrite->set_permalink_structure( '/%postname%/' );
		$wp_rewrite->flush_rules();
	}
}
