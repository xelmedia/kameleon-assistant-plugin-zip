<?php
/**
 * Zilch Debug Logger utilizing WordPress logging functions.
 *
 * @package Zilch Assistant
 */

namespace Zilch\Assistant\Alerting;

/**
 * Debug logger helper to log certain log levels using WordPress.
 */
class Debug_Logger {

	const LOG_LEVEL_DEBUG   = 'DEBUG';
	const LOG_LEVEL_INFO    = 'INFO';
	const LOG_LEVEL_ERROR   = 'ERROR';
	const LOG_LEVEL_WARNING = 'WARNING';

	/**
	 * Logs a message using WordPress's logging system.
	 *
	 * @param string $msg   The message to be logged.
	 * @param string $level The log level to be logged.
	 * @return void
	 */
	public static function log( string $msg, string $level = self::LOG_LEVEL_DEBUG ): void {
		$level = strtoupper( trim( $level ) );

		$now     = gmdate( 'Y-m-d H:i:s' );
		$log_row = "[$now] - $level: $msg";

		switch ( $level ) {
			case self::LOG_LEVEL_DEBUG:
				if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
					error_log( $log_row );
				}
				break;

			case self::LOG_LEVEL_INFO:
				error_log( $log_row );
				break;

			case self::LOG_LEVEL_WARNING:
			case self::LOG_LEVEL_ERROR:
				error_log( $log_row );
				break;

			default:
				error_log( "[UNKNOWN LEVEL] $log_row" );
				break;
		}
	}
}
