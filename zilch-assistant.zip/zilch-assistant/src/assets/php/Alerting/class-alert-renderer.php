<?php
/**
 * Back-end to Front-end alert rendered.
 * If errors/warnings/info/success cases occur within the PHP back-end, that need to be notified to the clients,
 * this class can be used to notify the front-end.
 *
 * @package Zilch Assistant
 */

namespace Zilch\Assistant\Alerting;

use Throwable;

/**
 * Alert Renderer for enqueued Zilch JS client code.
 * Makes use of cookies to set alerts to be recognized and rendered within the front-end.
 */
class Alert_Renderer {
	const ZILCH_ERROR_COOKIE_NAME   = 'zilch_gutenberg_error';
	const ZILCH_SUCCESS_COOKIE_NAME = 'zilch_gutenberg_success';

	/**
	 * Sets a error alert.
	 *
	 * @param string|null    $msg  The error message to be set.
	 * @param Throwable|null $cause The error cause to be set.
	 * @return void
	 */
	public static function set_error( ?string $msg, ?Throwable $cause = null ): void {
		if ( $msg ) {
			setcookie( self::ZILCH_ERROR_COOKIE_NAME, $msg, 0, '/' );

			if ( $cause ) {
				Debug_Logger::log( $cause->getMessage(), Debug_Logger::LOG_LEVEL_ERROR );
			} else {
				Debug_Logger::log( $msg, Debug_Logger::LOG_LEVEL_ERROR );
			}
		}
	}

	/**
	 * Sets success alert.
	 *
	 * @param string|null $msg The success message to be set.
	 * @return void
	 */
	public static function set_success( ?string $msg ): void {
		if ( $msg ) {
			setcookie( self::ZILCH_SUCCESS_COOKIE_NAME, $msg, 0, '/' );
		}
	}
}
