<?php
/**
 * Zilch Contact Form 7 output helper
 *
 * @package Zilch Assistant
 */

declare(strict_types=1);

namespace Zilch\Assistant;

use Exception;

/**
 * Contact Form 7 class helper to parse the raw HTML from the contact form.
 */
class Contact_Form_7 {
	/**
	 * API to transform id's to Contact Form 7 short codes.
	 *
	 * @var Short_Code_Loader
	 */
	private Short_Code_Loader $short_code_loader;

	/**
	 * Constructor.
	 *
	 * @param Short_Code_Loader $short_code_loader The shortcode loader API.
	 */
	public function __construct( Short_Code_Loader $short_code_loader ) {
		$this->short_code_loader = $short_code_loader;
	}

	/**
	 * Resolve the contact form 7 postback url.
	 *
	 * @param string $form_id The form_id that is included within the post-back URL.
	 * @return string
	 */
	public function get_post_back_url_path( string $form_id ): string {
		return rest_url( "/contact-form-7/v1/contact-forms/$form_id/feedback" );
	}

	/**
	 * Get the parsed fields of the Contact Form 7 form using `scan_form_tags`.
	 *
	 * @param string $form_id The form ID.
	 * @return array The parsed fields from the form.
	 * @throws Exception When the form cannot be retrieved.
	 */
	public function parse_contact_form_7( string $form_id ): array {
		$contact_form = wpcf7_contact_form( $form_id );

		if ( ! $contact_form ) {
			return array();
		}

		$form_tags = $contact_form->scan_form_tags();
		$form_fields = array();

		foreach ( $form_tags as $tag ) {
			$has_placeholder = count( $tag->labels ) > 1;

			$form_field = array(
				'name'        => $tag->name,
				'type'        => $tag->basetype,
				'label'       => '',
				'required'    => $tag->is_required(),
				'placeholder' => $has_placeholder ? $tag->labels[0] : '',
			);

			if ( isset( $tag->labels[0] ) ) {
				$form_field['label'] = $has_placeholder ? $tag->labels[1] : $tag->labels[0];
			}

			$form_fields[] = $form_field;
		}

		return $form_fields;
	}
}
