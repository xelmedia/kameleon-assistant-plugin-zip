<?php
/**
 * Autoloader for Zilch PHP classes. Will be loaded for any instantiated class within the `Zilch\Assistant` namespace.
 * This is used for conforming to the WordPress Coding styleguide, of which classes should be:
 * - Named with underscore: `My_Class`
 * - And its file: `class-my-class.php
 *
 * This is not automatically recognized as a valid class file conforming the class name by PSR-0/4.
 *
 * @package Zilch Assistant
 */

spl_autoload_register( 'zilch_autoloader' );

/**
 * Autoload callable to be registered when autoloading.
 *
 * @param string $class_name the className to be autoloaded.
 * @return void
 */
function zilch_autoloader( $class_name ) {
	$namespace_root = 'Zilch\Assistant';
	if ( str_starts_with( $class_name, $namespace_root ) ) {
		$classes_dir = __DIR__;
		$class_file  = trim( str_replace( $namespace_root, '', $class_name ), '\\' ) . '.php';
		$class_file  = str_replace( '\\', DIRECTORY_SEPARATOR, $class_file );

		$file_name = trim( basename( $class_file ), '\\' );
		$file_dir  = trim( str_replace( $file_name, '', $class_file ), '\\' );

		// Autoload class directly based on ClassName -> I_Test => I_Test.php.
		$require_default = $classes_dir . DIRECTORY_SEPARATOR . $class_file;
		if ( file_exists( $require_default ) ) {
			require_once $require_default;
			return;
		}

		// Autoload class directly based on ClassName -> I_Test => ITest.php.
		$require_camel_case = $classes_dir . DIRECTORY_SEPARATOR . str_replace( '_', '', $class_file );
		if ( file_exists( $require_camel_case ) ) {
			require_once $require_camel_case;
			return;
		}

		// Or fallback to PHP coding standard: `My_Class` -> `class-my-class.php`.
		$require_wp_standard = $classes_dir . DIRECTORY_SEPARATOR . $file_dir . DIRECTORY_SEPARATOR .
			'class-' . strtolower( str_replace( '_', '-', $file_name ) );
		if ( file_exists( $require_wp_standard ) ) {
			require_once $require_wp_standard;
			return;
		}
	}
}
