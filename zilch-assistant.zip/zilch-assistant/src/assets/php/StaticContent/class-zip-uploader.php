<?php
/**
 * Class to manage ZIP-uploads from the REST routes, supports chunks.
 * Also, it can unzip and deploy to the designated public_html location after upload is complete.
 *
 * @package Zilch Assistant
 */

namespace Zilch\Assistant\StaticContent;

use Exception;
use Zilch\Assistant\Alerting\Debug_Logger;
use Throwable;
use ZipArchive;

/**
 * Class responsible for handling zip uploads (in chunks or fully), unzipping (with maximum time) and deploying to a
 * static content directory.
 */
class Zip_Uploader {

	/**
	 * Maximum time in seconds a process may unzip before terminating.
	 */
	const MAX_UNZIP_TIME_SECONDS = 10;

	/**
	 * States whether the `unzip` command was executed.
	 *
	 * @var bool
	 */
	private bool $unzip_completed = false;

	/**
	 * The upload directory where uploaded files will be written to.
	 *
	 * @var string
	 */
	protected string $upload_dir;

	/**
	 * The upload zip path (within the upload_dir) where the zip file will be written to.
	 *
	 * @var string
	 */
	protected string $upload_zip_path;

	/**
	 * The static_content deploy path where the unzipped static content should be deployed to.
	 *
	 * @var string
	 */
	private string $static_content_deploy_path;

	/**
	 * The static_content backup path where current deployed content will be written to in case of failure.
	 *
	 * @var string
	 */
	private string $static_content_backup_path;


	/**
	 * Constructor.
	 */
	public function __construct() {
		global $zilch_wp_root;
		$this->upload_dir      = $zilch_wp_root . '/upload-static-content';
		$this->upload_zip_path = "$this->upload_dir/static-content.zip";

		global $zilch_static_content_dir;
		$this->static_content_deploy_path = $zilch_static_content_dir;
		$this->static_content_backup_path = "$zilch_wp_root/zilch_backup";
	}

	/**
	 * Writes a chunk of data from the PHP://input parameters to zip file.
	 *
	 * @param int    $current_chunk The current chunk number to be written to the zip file.
	 * @param string $source  The source file name to be written as chunk to the zip file.
	 * @return void
	 */
	public function write_zip_chunk( int $current_chunk, string $source = 'php://input' ): void {
		if ( $current_chunk <= 1 ) {
			File_System::remove_directory_with_contents( $this->upload_dir );
		}
		@mkdir( $this->upload_dir );
		File_System::write_source_file_to_file( $this->upload_zip_path, $source );
	}

	/**
	 * Verifies the zip file for completion based on a given md5 sum.
	 * Throws if invalid.
	 *
	 * @param string $md5_sum The md5 sum that should match the md5-sum of the zip file.
	 * @return void
	 * @throws Exception When zip not exists, zip is invalid or md5 checksum fails to verify.
	 */
	public function verify_zip( string $md5_sum ): void {
		if ( ! file_exists( $this->upload_zip_path ) ) {
			throw new Exception( esc_html( "Unable to verify md5 sum, no zip exists at: $this->upload_zip_path" ) );
		}

		$actual_md5 = md5_file( $this->upload_zip_path );
		if ( $md5_sum !== $actual_md5 ) {
			throw new Exception( esc_html( "Zip md5 checksum mismatch. Actual: $actual_md5, but expected: $md5_sum" ) );
		}
		$zip = new ZipArchive();
		try {
			if ( true !== $zip->open( $this->upload_zip_path, ZipArchive::CHECKCONS ) ) {
				$zip->close();
				throw new Exception( 'Invalid zip detected' );
			}
		} catch ( Throwable $e ) {
			throw new Exception( 'Invalid zip detected' );
		}
		$zip->close();
	}

	/**
	 * Unzips a zip archive file by file until the maximum process time is reached (MAX_UNZIP_TIME_SECONDS).
	 * Once reached, the remaining files still to be unzipped are returned.
	 *
	 * Each file that was unzipped, will be removed from the zipfile.
	 *
	 * If the returning int equals: 0, the unzip process is completed.
	 *
	 * @return int The number of remaining files to be unzipped. If 0, unzip is completed.
	 * @throws Exception When something unexpected occurs when opening or unzipping.
	 */
	public function unzip(): int {
		$start_time = time();
		$zip        = new ZipArchive();

		if ( $zip->open( $this->upload_zip_path ) === true ) {
			// Start unzipping process.
            // phpcs:disable
            for ( $i = 0; $i < $zip->numFiles; $i++ ) {
				// Check if maximum execution time has been reached.
				if ( ( time() - $start_time ) >= static::MAX_UNZIP_TIME_SECONDS ) {
					return $zip->numFiles;
				}
                // phpcs:enable

				// Extract file from the ZIP archive and remove from archive.
				$file_name = $zip->getNameIndex( $i );
				if ( ! $zip->extractTo( $this->upload_dir, $file_name ) ) {
					throw new Exception( esc_html( "Error unzipping $file_name to: $this->upload_dir" ) );
				}
				$zip->deleteName( $file_name );
			}
			$zip->close();
			$this->unzip_completed = true;
			return 0;
		} else {
			$file_exists = is_file( $this->upload_zip_path ) ? 'locating' : 'opening';
			$msg         = "Error $file_exists zipfile at: $this->upload_zip_path";
			Debug_Logger::log( $msg, Debug_Logger::LOG_LEVEL_ERROR );
			throw new Exception( esc_html( $msg ) );
		}
	}

	/**
	 * Deploys the unzipped content to the public static-content directory defined by the plugin within the document root.
	 * Has a fallback in case something fails, to still retain the existing deployed content.
	 *
	 * @return void
	 * @throws Exception Error when moving or removing files to static-content path.
	 */
	public function deploy(): void {
		if ( ! $this->unzip_completed ) {
			throw new Exception( 'Unzip should be executed first before deploying!' );
		}

		// Move existing static content to a backup location for fallback.
		try {
			File_System::remove_directory_with_contents( $this->static_content_backup_path );
			if ( is_dir( $this->static_content_deploy_path ) ) {
				rename( $this->static_content_deploy_path, $this->static_content_backup_path );
			}

			if ( ! rename( $this->upload_dir, $this->static_content_deploy_path ) ) {
				throw new Exception(
					"Moving ($this->upload_dir) to public_html ($this->static_content_backup_path) failed"
				);
			}
			File_System::remove_directory_with_contents( $this->static_content_backup_path );
		} catch ( Throwable $t ) {
			// Recover backup.
			if ( is_dir( $this->static_content_backup_path ) ) {
				rename( $this->static_content_backup_path, $this->static_content_deploy_path );
			}
			throw new Exception( esc_html( "Error moving unzipped content to public_html directory: {$t->getMessage()}" ) );
		}
	}
}
