<?php
/**
 * FileSystem helper tool. Wrapper around native PHP and WP_FileSystem.
 *
 * @package Zilch Assistant
 */

namespace Zilch\Assistant\StaticContent;

/**
 * FileSystem helpers
 */
class File_System {

	/**
	 * Removes a given directory, with its contents recursively. Equal to: `rm -r`.
	 * The directory itself will be removed after the directory contents are removed.
	 *
	 * @param string $dir   The directory path to be removed.
	 * @return void
	 */
	public static function remove_directory_with_contents( string $dir ): void {
		if ( ! is_dir( $dir ) ) {
			return;
		}
		foreach ( scandir( $dir ) as $file ) {
			if ( '.' === $file || '..' === $file ) {
				continue;
			}
			if ( is_dir( "$dir/$file" ) ) {
				self::remove_directory_with_contents( "$dir/$file" );
			} else {
				unlink( "$dir/$file" );
			}
		}
		rmdir( $dir );
	}

	/**
	 * Writes source file contents to a given filePath.
	 * The source file will be read in chunks of 8192 bytes, to keep memory usage low.
	 *
	 * @param string $dest_file_path  The destination file path.
	 * @param string $source_file_path The source file path.
	 * @return void
	 */
	public static function write_source_file_to_file( string $dest_file_path, string $source_file_path ): void {
		$zip_handle = fopen( $dest_file_path, 'a' );

		$data_handle = fopen( $source_file_path, 'rb' );
		while ( ! feof( $data_handle ) ) {
			fwrite( $zip_handle, fread( $data_handle, 8192 ) );
		}
		fclose( $data_handle );
		fclose( $zip_handle );
	}
}
