<?php
/**
 * Zilch GraphQL output helper
 *
 * @package Zilch Assistant
 */

declare(strict_types=1);

namespace Zilch\Assistant;

use Exception;
use Zilch\Assistant\Alerting\Debug_Logger;


/**
 * GraphQL class helper to format attributes JSON response
 */
class Graphql {
	/**
	 * The input response data that will be formatted.
	 *
	 * @var array
	 */
	private array $response_data;

	/**
	 * The contact_form_7 API helper to parse data from.
	 *
	 * @var Contact_Form_7
	 */
	private Contact_Form_7 $contact_form_7;

	/**
	 * The graphql block info helper.
	 *
	 * @var Graphql_Block_Info
	 */
	private Graphql_Block_Info $graphql_block_info;

	/**
	 * Search data in blocks for a maximum of..
	 *
	 * @var int
	 */
	private int $max_block_search_depth = 6;

	/**
	 * Constructs a GraphQL helper which can be used to format the input $response_data.
	 *
	 * @param array              $response_data   raw input $response_data to be formatted.
	 * @param Contact_Form_7     $contact_form_7  contact form 7 api.
	 * @param Graphql_Block_Info $graphql_block_info graphql block info helper API.
	 */
	public function __construct(
		array $response_data,
		Contact_Form_7 $contact_form_7,
		Graphql_Block_Info $graphql_block_info
	) {
		$this->response_data      = $response_data;
		$this->contact_form_7     = $contact_form_7;
		$this->graphql_block_info = $graphql_block_info;
	}

	/**
	 * Maps through the given data, with a given depth, and a given callable to handle each data within that block.
	 * Searches for the key 'blocks' within the given data.
	 *
	 * @param array    $data    Data to be mapped.
	 * @param callable $map_function    Callable map function that will be called upon each data block iteration.
	 * @param int      $depth   The current depth the given $data block is currently relative to the initial input data.
	 * @return void
	 */
	private function map_blocks( array &$data, callable $map_function, int $depth ): void {
		if ( array_key_exists( 'blocks', $data ) && is_array( $data['blocks'] ) ) {
			$blocks = &$data['blocks'];
			$map_function( $blocks );
		} elseif ( $depth <= $this->max_block_search_depth ) {
			foreach ( $data as &$sub_data ) {
				if ( is_array( $sub_data ) ) {
					$this->map_blocks( $sub_data, $map_function, $depth + 1 );
				}
			}
		}
	}

	/**
	 * Public accessor to format the data given within the constructor.
	 *
	 * @return array    Return the formatted response data.
	 * @throws Exception When something unexpected occurs.
	 */
	public function reformat_response_data(): array {
		$reformatted_response_data = $this->response_data;
		$this->map_blocks(
			$reformatted_response_data,
			function ( array &$blocks ) {
				$this->reformat_blocks( $blocks );
			},
			0
		);
		return $reformatted_response_data;
	}

	/**
	 * To get from blockName to attributeNames we take the part after the first '--',
	 * which indicates the end of the parentBlockName and start of the attribute names.
	 * Then we split the remainder by '--', which gives us separate attribute names.
	 * If the attribute name contains '-wrapper', remove that because it indicates a wrapper block
	 * which is sort of an artificial block not contained in the block info attributes.
	 *
	 * Lastly replace each '-' followed by a lowercase letter with the uppercase letter,
	 * which will give us the attribute name as it is in the blockInfoAttributes.
	 *
	 * @param string $block_name The name of the block to resolve the attributes from.
	 * @return string[]
	 */
	private function get_attribute_names_from_block_name( string $block_name ): array {
		$attr_name_kebab = substr( $block_name, strpos( $block_name, '--' ) + 2 );
		return array_map(
			function ( $name ) {
				$name = str_replace( '-wrapper', '', $name );
				return preg_replace_callback(
					'/-([a-z])/',
					function ( $matches ) use ( $name ) {
						return strtoupper( $matches[1] );
					},
					$name
				);
			},
			explode( '--', $attr_name_kebab )
		);
	}

	/**
	 *
	 * Will loop recursively over menuItems to add subMenu items
	 *
	 * @param array $items  mainMenuItems to build.
	 * @return array
	 */
	private function build_menu_array( array $items ): array {
		$menu_items_by_parent = array();
		foreach ( $items as $item ) {
			$menu_item = array(
				'id'      => $item->ID,
				'label'   => $item->title,
				'link'    => $item->url,
				'parent'  => $item->menu_item_parent,
				'subMenu' => array(),
			);

			$menu_items_by_parent[ $item->menu_item_parent ][] = $menu_item;
		}

		$func_build_submenu = function ( $parent_id ) use ( &$func_build_submenu, &$menu_items_by_parent ) {
			$menu = array();
			if ( isset( $menu_items_by_parent[ $parent_id ] ) ) {
				foreach ( $menu_items_by_parent[ $parent_id ] as $item ) {
					$item['subMenu'] = $func_build_submenu( $item['id'] );
					$menu[]          = $item;
				}
			}
			return $menu;
		};

		$menu = $func_build_submenu( 0 );

		return $menu;
	}

	/**
	 * Will format each blocks
	 *
	 * @param array       $blocks bLocks to be formatted.
	 * @param string|null $parent_package_name The parents package name it refers to.
	 * @return void
	 * @throws Exception When something unexpected occurs.
	 */
	private function reformat_blocks( array &$blocks, ?string $parent_package_name = null ): void {
		foreach ( $blocks as &$block ) {
			$attributes_json = json_decode( $block['attributesJSON'], true );
			if ( isset( $attributes_json['packageName'] ) ) {
				$block_info_attributes       = $this->graphql_block_info->get_block_info_attributes( $attributes_json['packageName'] );
				$reformatted_attributes_json = $this->reformat_attributes_json( $attributes_json, $block_info_attributes );
				// Encode the reformatted 'attributesJSON'.
				$block['attributesJSON'] = json_encode( $reformatted_attributes_json, JSON_UNESCAPED_SLASHES );
			} elseif ( null === $parent_package_name ) {
					Debug_Logger::log(
						"reformatBlocks for an InnerBlock needs $parent_package_name, but it is null",
						Debug_Logger::LOG_LEVEL_WARNING
					);
			}
		}
	}

	/**
	 * Re formats the attributes_json output from GraphQL to parse additional fields/data.
	 *
	 * @param array $attributes_json the input attributes to be formatted.
	 * @param array $block_info_attributes The attributes from the block_info.
	 * @return array to formatted output attributes json.
	 * @throws Exception When something unexpected occurs.
	 */
	private function reformat_attributes_json( array $attributes_json, array $block_info_attributes ): array {
		foreach ( $attributes_json as $key => $value ) {
			if ( isset( $block_info_attributes[ $key ] ) ) {
				$block_info_attribute = $block_info_attributes[ $key ];

				if ( 'SecondaryBlock' === $key || 'TertiaryBlock' === $key ) {
					if ( ! empty( $value ) ) {
						if ( key_exists( 'attributes', $value ) ) {
							$value['blockProps'] = $this->reformat_attributes_json( $value['attributes'], $this->graphql_block_info->get_block_info_attributes( $value['packageName'] ) );
							unset( $value['name'] );
							unset( $value['attributes'] );
						}
					}

					$attributes_json[ $key ] = $value;
				}

				if ( 'form' === $block_info_attribute['type'] ) {
					if ( is_numeric( $value ) ) {
						$attributes_json[ $key ]                 = $this->contact_form_7->parse_contact_form_7( $value );
						$attributes_json['_contactFormSettings'] = array(
							'postUrl' => $this->contact_form_7->get_post_back_url_path( $value ),
							'formId'  => (int) $value,
						);
					}
				}
				if ( 'menu' === $block_info_attribute['type'] ) {
					$nav_items = wp_get_nav_menu_items( $value, true );
					if ( ! $nav_items ) {
						$nav_items = array();
					}
					$attributes_json[ $key ] = $this->build_menu_array( $nav_items );
				}

				if ( 'array' === $block_info_attribute['type'] && 'object' === $block_info_attribute['items']['type'] && ! empty( $value ) ) {
					$reformated_array = array();

					foreach ( $value as $k ) {
						$reformated_array[] = $this->reformat_attributes_json( $k, $block_info_attribute['items']['attributes'] );
					}

					$attributes_json[ $key ] = $reformated_array;
				}
			} elseif ( 'FooterWidgets' === $key ) {
				$attributes_json[ $key ] = array();
			}
		}

		return $attributes_json;
	}
}
