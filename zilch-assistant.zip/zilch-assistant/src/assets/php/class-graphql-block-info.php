<?php
/**
 * Zilch GraphQL blockinfo helper
 *
 * @package Zilch Assistant
 */

declare(strict_types=1);

namespace Zilch\Assistant;

use Exception;
use Zilch\Assistant\Alerting\Debug_Logger;
use Zilch\Assistant\Clients\Zilch\Helpers\Zilch_Gateway_Client_Helper;

/**
 * GraphQL class helper to parse and resolve blockinfo attributes.
 */
class Graphql_Block_Info {


	/**
	 * Constructor
	 */
	public function __construct() {
	}

	/**
	 * Keep previously loaded blockInfo's in a static array as a cache.
	 *
	 * @var array
	 */
	protected static array $block_infos = array();

	/**
	 * Get the blockInfo attributes given a packageName. Calling the gateway service to receive the blockinfo.
	 * If an array of attribute_names is given, the blockinfoAttributes are recursively searched for the attribute_names.
	 * This occurs for innerBlocks. An attribute_names array of length > 1 can happen for innerBlocks in innerBlocks.
	 *
	 * @param string     $package_name    The package name of the Zilch layout to parse the attributes from, from the blockinfo.
	 * @param array|null $attribute_names The attributes to be looked up.
	 * @return array
	 * @throws Exception Will throw an exception if the block was not found.
	 */
	public function get_block_info_attributes( string $package_name, ?array $attribute_names = array() ): array {
		if ( ! isset( static::$block_infos[ $package_name ] ) ) {
			$client  = Zilch_Gateway_Client_Helper::get_gateway_client_instance();
			$content = $client->get_block_by_package_name( $package_name );
			if ( $content ) {
				$block_info                           = json_decode( $content, true );
				static::$block_infos[ $package_name ] = $block_info;
			} else {
				Debug_Logger::log( "Unable to get blockInfo for packageName $package_name, file not present or not readable", 'ERROR' );
				return array();
			}
		}

		$block_info_attributes = static::$block_infos[ $package_name ]['attributes'] ?? array();
		if ( empty( $block_info_attributes ) ) {
			Debug_Logger::log( "Unable to parse attributes from blockInfo for packageName $package_name", 'ERROR' );
			return array();
		}

		foreach ( $attribute_names as $attribute_name ) {
			if ( ! isset( $block_info_attributes[ $attribute_name ] ) ) {
				// if the attribute name is not found in the blockInfoAttributes, the blockInfoAttributes itself may be the one for the attribute_name,
				// this happens for instance with secondaryBlock and tertiaryBlock, because they have their own blockInfo file.
				continue;
			}
			if ( isset( $block_info_attributes[ $attribute_name ]['items'] ) ) {
				$block_info_attributes = $block_info_attributes[ $attribute_name ]['items']['attributes'] ?? array();
			} else {
				$block_info_attributes = $block_info_attributes[ $attribute_name ]['attributes'] ?? array();
			}
		}
		return $block_info_attributes;
	}
}
