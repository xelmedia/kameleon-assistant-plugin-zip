<?php
/**
 * Zilch Options API to resolve Zilch config on run-time.
 *
 * @package Zilch Assistant
 */

namespace Zilch\Assistant;

use Exception;

/**
 * Zilch Config helper. Uses WP_Option API from WP Core to resolve WP_Options.
 */
class Zilch_Options {
	public const TEXT_DOMAIN = 'zilch-assistant';

	/**
	 * Loads the current site's hostname.
	 *
	 * @note This is not URL format, so schema (http://|https://) is not included.
	 *
	 * @return string
	 */
	public static function get_site_host(): string {
		return wp_parse_url( get_site_url(), PHP_URL_HOST );
	}

	/**
	 * Returns the registered `zilch_client_secret`, in base64 encoded format, that is stored in WP_options.
	 *
	 * @return string
	 * @throws Exception When option does not exist.
	 */
	public static function get_client_secret(): string {
		return self::get_option( 'zilch_client_secret', true );
	}

	/**
	 * Updates/Sets the `zilch_client_secret` WP_Option.
	 *
	 * @param string $client_secret Client secret to be set, if plain text, it will be stored as base64.
	 * @return void
	 */
	public static function update_client_secret( string $client_secret ): void {
		if ( ! base64_decode( $client_secret, true ) ) {
			$client_secret = base64_encode( $client_secret );
		}
		update_option( 'zilch_client_secret', $client_secret );
	}

	/**
	 * Resolves the Zilch Gateway host.
	 *
	 * @return string
	 * @throws Exception When `zilch_gateway_host` WP_Option does not exist.
	 */
	public static function get_gateway_host(): string {
		return self::get_option( 'zilch_gateway_host', true );
	}

	/**
	 * Generic function to resolve a WP_Option with mandatory checks.
	 *
	 * @param string $option    The WP_Option name to resolve.
	 * @param bool   $mandatory   Marks whether the option must be present.
	 * @return string|null
	 * @throws Exception    When $mandatory parameter is set to true, and the WP_Option does not exist.
	 */
	private static function get_option( string $option, bool $mandatory ): ?string {
		$value = get_option( $option );
		if ( ! $value && $mandatory ) {
			throw new Exception( wp_json_encode( "$option` option is not set in options." ), 404 );
		}
		return $value ?? null;
	}
}
