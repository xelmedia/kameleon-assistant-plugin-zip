<?php
/**
 * Zilch Gateway Client interface for conforming to API.
 *
 * @package Zilch Assistant
 */

declare(strict_types=1);

namespace Zilch\Assistant\Clients\Zilch;

use Exception;
use Zilch\Assistant\Clients\Zilch\Domain\Build_Site_Request;

/**
 * Zilch Gateway client interface to conform to when implementing client for Zilch Gateway API.
 */
interface I_Zilch_Gateway_Client {
	/**
	 * Execute a build site request to the Zilch Gateway API.
	 *
	 * @param Build_Site_Request $build_site_request The contextual build site request.
	 * @return void
	 * @throws Exception When API returns and unexpected status code.
	 */
	public function build_site( Build_Site_Request $build_site_request ): void;

	/**
	 * Request to get the block info given a package name
	 *
	 * @param string $package_name Package name.
	 * @return string|null
	 * @throws Exception Will throw an exception if the package was not found or something went wrong while making the request.
	 */
	public function get_block_by_package_name( string $package_name ): ?string;

	/**
	 * Request to get the blocks info given a block type
	 *
	 * @param string $block_type Block type.
	 * @return string|null
	 * @throws Exception Will throw an exception if something went wrong while making the request.
	 */
	public function get_block_by_type( string $block_type ): ?string;

	/**
	 * Create or get singleton instance of the client.
	 *
	 * @return I_Zilch_Gateway_Client
	 */
	public static function instance(): I_Zilch_Gateway_Client;
}
