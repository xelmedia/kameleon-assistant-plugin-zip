<?php
/**
 * Build Site request body for building static content using the Zilch Gateway API.
 *
 * @package Zilch Assistant
 */

namespace Zilch\Assistant\Clients\Zilch\Domain;

/**
 * Request object for Building static content using the Zilch API.
 */
class Build_Site_Request implements Json_Content {
	/**
	 * The domainName, matches the site_host of this WP installation, to build static content for.
	 *
	 * @var string
	 */
	private string $domain_name;

	/**
	 * The ip address of the server that the site runs on.
	 *
	 * @var string
	 */
	private string $ip_address;

	/**
	 * Constructor.
	 *
	 * @param string $domain_name   The domainName to build the static content for.
	 * @param string $ip_address    The ip address of the server that site runs on.
	 */
	public function __construct( string $domain_name, string $ip_address ) {
		$this->domain_name = $domain_name;
		$this->ip_address  = $ip_address;
	}

	/**
	 * Get domainName field value.
	 *
	 * @return string
	 */
	public function get_domain_name(): string {
		return $this->domain_name;
	}

	/**
	 * Get ipAddress field value.
	 *
	 * @return string
	 */
	public function get_ip_address(): string {
		return $this->ip_address;
	}

	/**
	 * Serialize build site request to raw JSON string.
	 *
	 * @return string
	 */
	public function to_json(): string {
		$body = array(
			'domainName' => $this->domain_name,
			'ipAddress'  => $this->ip_address,
		);
		return wp_json_encode( $body );
	}

	/**
	 * Deserialized raw JSON string to build site request.
	 *
	 * @param string $data  The raw JSON data to be deserialized.
	 * @return Build_Site_Request
	 */
	public static function from_json( string $data ): Build_Site_Request {
		$decoded = json_decode( $data, true );
		return new Build_Site_Request( $decoded['domainName'] ?? null, $decoded['ipAddress'] ?? null );
	}
}
