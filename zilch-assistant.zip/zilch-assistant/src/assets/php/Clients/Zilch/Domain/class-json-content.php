<?php
/**
 * JSON Content interface for Zilch Client request/response objects.
 * Used to standardize serialization and deserialization.
 *
 * @package Zilch Assistant
 */

namespace Zilch\Assistant\Clients\Zilch\Domain;

/**
 * Interface for Zilch Client request and response object to conform to.
 */
interface Json_Content {

	/**
	 * Implement to serialize object to json.
	 *
	 * @return string
	 */
	public function to_json(): string;

	/**
	 * Implement to deserialize raw JSON data to object instance.
	 *
	 * @param string $data The raw JSON data to be deserialized.
	 * @return Json_Content
	 */
	public static function from_json( string $data ): Json_Content;
}
