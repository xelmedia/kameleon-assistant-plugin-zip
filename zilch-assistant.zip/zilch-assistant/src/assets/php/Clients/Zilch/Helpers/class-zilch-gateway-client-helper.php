<?php
/**
 * Zilch Gateway Client Helper
 *
 * @package Zilch Assistant
 */

declare(strict_types=1);

namespace Zilch\Assistant\Clients\Zilch\Helpers;

use Exception;
use Zilch\Assistant\Zilch_Options;
use Zilch\Assistant\Clients\Zilch\I_Zilch_Gateway_Client;
use Zilch\Assistant\Clients\Zilch\Zilch_Gateway_Client;
use Zilch\Assistant\Clients\Zilch\Mocks\Zilch_Gateway_Client_Mock;

/**
 * Zilch Gateway helper class that contains some static methods that will help the gateway client.
 */
class Zilch_Gateway_Client_Helper {
	const MOCKED_GATEWAY_HOST = 'gateway-mocked-test.nl';

	/**
	 * Will create (get existing) instance of the gateway client.
	 *
	 * @throws Exception Will throw an error if the gateway host is not set as an option.
	 */
	public static function get_gateway_client_instance(): I_Zilch_Gateway_Client {
		$gateway_host = Zilch_Options::get_gateway_host();
		if ( self::MOCKED_GATEWAY_HOST === $gateway_host ) {
			return Zilch_Gateway_Client_Mock::instance();
		}
		return Zilch_Gateway_Client::instance();
	}
}
