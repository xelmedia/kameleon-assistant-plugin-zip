<?php
/**
 * Zilch Gateway API Client.
 *
 * @package Zilch Assistant
 */

declare(strict_types=1);

namespace Zilch\Assistant\Clients\Zilch;

use Exception;
use Zilch\Assistant\Clients\Header;
use Zilch\Assistant\Clients\Zilch_Http_Client;
use Zilch\Assistant\Clients\Zilch\Domain\Build_Site_Request;
use Zilch\Assistant\Zilch_Options;

/**
 * Zilch Gateway API client to make requests to the Zilch Gateway API.
 */
class Zilch_Gateway_Client implements I_Zilch_Gateway_Client {
	const GATEWAY_API_POST_BUILD_PATH           = '/v1/builds/site';
	const GATEWAY_API_GET_BLOCKS                = '/v1/blocks';
	const GATEWAY_API_GET_BLOCK_BY_PACKAGE_NAME = '/v1/blocks/:package-name';

	/**
	 * The HTTP Client to be used to handle requests.
	 *
	 * @var Zilch_Http_Client
	 */
	protected Zilch_Http_Client $client;

	/**
	 * The headers to be sent on each request.
	 *
	 * @var Header[]
	 */
	protected array $headers;

	/**
	 * Constructor.
	 *
	 * @throws Exception  When mandatory Zilch Options do not exist.
	 */
	protected function __construct() {
		$this->headers = array(
			Header::create( 'X-Zilch-Client-Secret', Zilch_Options::get_client_secret() ),
			Header::create( 'X-Zilch-Client-Host', Zilch_Options::get_site_host() ),
		);
		$this->client  = new Zilch_Http_Client( Zilch_Options::get_gateway_host() );
	}

	/**
	 * Request a build site at the Zilch Gateway.
	 *
	 * @param Build_Site_Request $build_site_request  The build site request data.
	 * @return void
	 * @throws Exception When build site request fails.
	 */
	public function build_site( Build_Site_Request $build_site_request ): void {
		$this->client->do_post(
			self::GATEWAY_API_POST_BUILD_PATH,
			$build_site_request,
			$this->headers
		);
	}

	/**
	 * Retrieves cached data from the cache directory if it exists and is not expired.
	 *
	 * @param string $cache_key The unique key identifying the cached data.
	 * @param int    $expiration The cache expiration time in seconds. Defaults to 6 hours (21600 seconds).
	 *
	 * @return string|null The cached data as a string if available and valid, or null if not found or expired.
	 */
	private function get_cached_data( string $cache_key, int $expiration = 21600 ): ?string {
		$cache_dir = plugin_dir_path( __FILE__ ) . 'cache/';
		if ( ! file_exists( $cache_dir ) ) {
			mkdir( $cache_dir, 0755, true );
		}

		$cache_file = $cache_dir . md5( $cache_key ) . '.json';

		if ( file_exists( $cache_file ) && ( time() - filemtime( $cache_file ) ) < $expiration ) {
			$cached_data = file_get_contents( $cache_file );
			return $cached_data ? $cached_data : null;
		}

		return null;
	}

	/**
	 * Saves data to the cache directory.
	 *
	 * @param string $cache_key The unique key used to identify the cached data.
	 * @param string $data The data to be cached, stored as a string.
	 *
	 * @return void
	 */
	private function cache_data( string $cache_key, string $data ): void {
		$cache_dir = plugin_dir_path( __FILE__ ) . 'cache/';
		if ( ! file_exists( $cache_dir ) ) {
			mkdir( $cache_dir, 0755, true );
		}

		$cache_file = $cache_dir . md5( $cache_key ) . '.json';

		file_put_contents( $cache_file, $data );
	}

	/**
	 * Request to get the block info given a package name
	 *
	 * @param string $package_name Package name.
	 * @return string|null
	 * @throws Exception Will throw an exception if the package name was not found.
	 */
	public function get_block_by_package_name( string $package_name ): ?string {
		$cache_key = 'package_name_' . $package_name;

		$cached_data = $this->get_cached_data( $cache_key );
		if ( $cached_data ) {
			return $cached_data;
		}

		$path         = str_replace( ':package-name', urlencode( $package_name ), self::GATEWAY_API_GET_BLOCK_BY_PACKAGE_NAME );
		$api_response = $this->client->do_get( $path, $this->headers );

		if ( $api_response ) {
			$this->cache_data( $cache_key, $api_response );
		}

		return $api_response;
	}

	/**
	 * Request to get the blocks info given a block type
	 *
	 * @param string $block_type Block type.
	 * @return string|null
	 * @throws Exception Will throw an exception if something went wrong while making the request.
	 */
	public function get_block_by_type( string $block_type ): ?string {
		$cache_key = 'block_type_' . $block_type;

		$cached_data = $this->get_cached_data( $cache_key );
		if ( $cached_data ) {
			return $cached_data;
		}

		$path         = self::GATEWAY_API_GET_BLOCKS . '?byType=' . urlencode( $block_type );
		$api_response = $this->client->do_get( $path, $this->headers );
		if ( $api_response ) {
			$this->cache_data( $cache_key, $api_response );
		}

		return $api_response;
	}

	/**
	 * Singleton instance.
	 *
	 * @var I_Zilch_Gateway_Client|null
	 */
	protected static I_Zilch_Gateway_Client|null $instance = null;

	/**
	 * Zilch Gateway API client to instantiate using Singleton pattern.
	 *
	 * @return I_Zilch_Gateway_Client
	 */
	public static function instance(): I_Zilch_Gateway_Client {
		if ( null === self::$instance ) {
			self::$instance = new Zilch_Gateway_Client();
		}
		return self::$instance;
	}
}
