<?php
/**
 * HTTP Client for making requests and handle response.
 *
 * @package Zilch Assistant
 */

namespace Zilch\Assistant\Clients;

use Exception;
use WP_Error;
use Zilch\Assistant\Clients\Zilch\Domain\Json_Content;

/**
 * HTTP Client wrapper around WP_Remote_Request with request and response handling.
 */
class Zilch_Http_Client {
	/**
	 * Override the default WP_Remote_Request args.
	 *
	 * @var array|true[]
	 */
	public array $override_args = array(
		'sslverify' => true,
	);

	private const JSON_HEADERS = array(
		'Content-Type' => 'application/json',
		'Accept'       => 'application/json',
	);

	/**
	 * Base URL of the API to send requests to.
	 *
	 * @var string
	 */
	private string $base_url;

	/**
	 * Constructor.
	 *
	 * @param string $host Base hostname to make requests to. Parses and sets schema and port based on host.
	 */
	public function __construct( string $host ) {
		$host_name = $host;
		if ( str_starts_with( $host, 'http' ) ) {
			$host_name = wp_parse_url( $host, PHP_URL_HOST );
		}

		$schema = wp_parse_url( $host, PHP_URL_SCHEME ) ?? 'https';
		$port   = wp_parse_url( $host, PHP_URL_PORT ) ?? 443;

		$host_name = trim( trim( $host_name ), '/' );
		$host_name = str_replace( ":$port", '', $host_name );

		$this->base_url = "$schema://$host_name:$port";
		if ( str_starts_with( $this->base_url, 'http://' ) ) {
			$this->override_args['sslverify'] = false;
		}
	}

	/**
	 * Getter for the base_url.
	 *
	 * @return string
	 */
	public function get_base_url(): string {
		return $this->base_url;
	}

	/**
	 * Generics implementation to make POST requests.
	 *
	 * @param string       $path The relative path (to the base_url) of the API to make the request to.
	 * @param Json_Content $body The request body.
	 * @param Header[]     $headers The additional headers to be sent. May override default headers.
	 * @return string|null
	 * @throws Exception When request to the API returns a invalid response code.
	 */
	public function do_post( string $path, Json_Content $body, array $headers = array() ): ?string {
		return $this->do_request( $path, 'POST', $body, $headers );
	}

	/**
	 * Generics implementation to make HTTP GET requests.
	 *
	 * @param string   $path The relative path (to the base_url) of the API to make the request to.
	 * @param Header[] $headers The additional headers to be sent. May override default headers.
	 * @return string|null
	 * @throws Exception When request to the API returns a invalid response code.
	 */
	public function do_get( string $path, array $headers = array() ): ?string {
		return $this->do_request( $path, 'GET', null, $headers );
	}

	/**
	 * Generics function to make HTTP request using the WP_Remote_request API.
	 *
	 * @param string            $path   The relative path (to the base_url) to make the request to.
	 * @param string            $method The method for the request: POST,PUT,DELETE,GET etc.
	 * @param Json_Content|null $body   The request body, if applicable.
	 * @param Header[]          $headers The request headers to be send.
	 * @return string|null
	 * @throws Exception When request to the API returns a invalid response code.
	 */
	private function do_request( string $path, string $method, Json_Content $body = null, array $headers = array() ): ?string {
		$path     = trim( trim( $path ), '/' );
		$full_url = $this->base_url . "/$path";

		$headers_to_send = self::JSON_HEADERS;
		foreach ( $headers as $header ) {
			$headers_to_send[ $header->get_name() ] = $header->get_value();
		}

		$request_options = array(
			'headers' => $headers_to_send,
			'method'  => $method,
			'timeout' => 60,
		);

		if ( null !== $body ) {
			$request_options['body'] = $body->to_json();
		}

		$result = wp_remote_request(
			$full_url,
			array_merge(
				$request_options,
				$this->override_args
			)
		);

		if ( $result instanceof WP_Error ) {
			throw new Exception(
				wp_json_encode(
					"Error doing $method request to $full_url -> " .
					"Error: ->\n     ResponseBody: " . wp_json_encode( $result ),
					500,
					null
				)
			);
		}

		$response    = $result['response'] ?? array();
		$result_body = $result['body'] ?? '';
		$code        = $response['code'] ?? 500;
		$msg         = $response['message'] ?? 'Something went wrong. Check logs';

		$code = is_numeric( $code ) ? (int) $code : 500;
		if ( $code < 200 || $code >= 400 ) {
			throw new Exception(
				wp_json_encode(
					"Error doing $method request to $full_url -> " .
					"Error: $msg ->\n     ResponseBody: $result_body",
					$code
				),
                // phpcs:disable
                $code
                // phpcs:enable
			);
		}
		return $result['body'] ?? null;
	}
}
