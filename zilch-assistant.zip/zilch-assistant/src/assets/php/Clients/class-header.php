<?php
/**
 * HTTP Header wrapper (tuple).
 *
 * @package Zilch Assistant
 */

namespace Zilch\Assistant\Clients;

/**
 * HTTP Request header wrapper containing nothing more than a key-value pair (tuple format).
 */
class Header {
	/**
	 * Name of the header.
	 *
	 * @var string
	 */
	private string $name;

	/**
	 * Value of the header belonging to the header $name.
	 *
	 * @var string
	 */
	private string $value;

	/**
	 * Create Header object by bypassing the constructor.
	 *
	 * @param string $name Header name attribute.
	 * @param string $value Header value attribute.
	 * @return self
	 */
	public static function create( string $name, string $value ): self {
		return new self( $name, $value );
	}

	/**
	 * Constructor.
	 *
	 * @param string $name Header name attribute.
	 * @param string $value Header value attribute.
	 */
	private function __construct( string $name, string $value ) {
		$this->name  = $name;
		$this->value = $value;
	}

	/**
	 * Getter for $name attribute.
	 *
	 * @return string
	 */
	public function get_name(): string {
		return $this->name;
	}

	/**
	 * Getter for $value attribute.
	 *
	 * @return string
	 */
	public function get_value(): string {
		return $this->value;
	}
}
