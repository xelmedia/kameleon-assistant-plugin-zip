import { AttributeType, BlockInfoAttribute } from "@kameleon-core/types"
import React, { ReactNode } from "react"
import { TextControl } from "@wordpress/components"
import { BlockAttributes } from "@wordpress/blocks"
import { HeadingEdit } from "./edit-fields/heading-edit"
import { MediaArrayEdit } from "./edit-fields/media-array-edit"
import { MenuEdit } from "./edit-fields/menu-edit"
import { FormEdit } from "./edit-fields/form-edit"
import { IconEdit } from "./edit-fields/icon-edit"
import { MediaEdit } from "./edit-fields/media-edit"
import { ItemsEdit } from "./edit-fields/items-edit"
import { RichTextEdit } from "./edit-fields/rich-text-edit"
import { ButtonEdit } from "./edit-fields/button-edit"

type EditFieldProps = {
  attributeName: string
  blockAttribute: BlockInfoAttribute
  attributes: BlockAttributes
  setAttributes: (attrs: Partial<BlockAttributes>) => void
}

export const EditField = ({ attributeName, blockAttribute, setAttributes, attributes }: EditFieldProps): ReactNode => {
  if (blockAttribute.type === AttributeType.Media) {
    return <MediaEdit attributes={attributes} setAttributes={setAttributes} attributeName={attributeName} />
  }

  if (blockAttribute.type === AttributeType.Icon) {
    return (
      <div data-title={attributeName}>
        <IconEdit
          value={attributes[attributeName]}
          setAttribute={(icon): void => setAttributes({ [attributeName]: icon })}
        />
      </div>
    )
  }

  if (blockAttribute.type === AttributeType.Form) {
    return <FormEdit attributes={attributes} setAttributes={setAttributes} attributeName={attributeName} />
  }
  if (blockAttribute.type === AttributeType.Menu) {
    return <MenuEdit attributes={attributes} setAttributes={setAttributes} attributeName={attributeName} />
  }

  if (blockAttribute.type === AttributeType.Number) {
    return (
      <TextControl
        value={attributes[attributeName] || ""}
        placeholder={attributeName}
        step={1}
        min={1}
        type={"number"}
        onChange={(newValue): void => setAttributes({ [attributeName]: newValue })}
      />
    )
  }

  if (blockAttribute.type === AttributeType.Array && blockAttribute.items.type === AttributeType.Media) {
    return <MediaArrayEdit attributes={attributes} setAttributes={setAttributes} attributeName={attributeName} />
  }

  if (blockAttribute.type === AttributeType.Heading) {
    return <HeadingEdit attributes={attributes} setAttributes={setAttributes} attributeName={attributeName} />
  }

  if (blockAttribute.type === AttributeType.Button || blockAttribute.type === AttributeType.Buttons) {
    const maxLength = blockAttribute.maxLength ?? 1

    return (
      <ButtonEdit
        maxLength={maxLength}
        attributes={attributes}
        setAttributes={setAttributes}
        attributeName={attributeName}
      />
    )
  }

  if (blockAttribute.type === AttributeType.Array) {
    return (
      <ItemsEdit
        setAttributes={setAttributes}
        blockAttribute={blockAttribute}
        attributeName={attributeName}
        attributes={attributes}
      />
    )
  }

  return (
    <RichTextEdit
      attributeName={attributeName}
      blockAttribute={blockAttribute}
      attributes={attributes}
      setAttributes={setAttributes}
    />
  )
}
