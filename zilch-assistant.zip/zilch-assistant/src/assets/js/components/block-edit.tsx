import React, { ReactNode, useEffect } from "react"
import { BlockType } from "@kameleon-core/types"
import { BlockAttributes, BlockEditProps as WpBlockEditProps } from "@wordpress/blocks"
import { useBlockProps } from "@wordpress/block-editor"
import { dispatch, useSelect } from "@wordpress/data"
import { ExtendedBlockInfoAttributes, isInnerBlockAttribute, isSecondaryOrTertiary } from "../blocks"
import { sortAttributes } from "../utils"
import { EditField } from "./edit-field"
import { SupportiveBlock } from "./edit-fields/supportive-block"
import { CollectionEdit } from "./edit-fields/collection-edit"
import { ZILCH_EDITOR_STORE, ZilchEditorActions } from "../redux/editor/zilch-editor-store"

type BlockEditProps = {
  blockName: string
  clientId: string
  blockType: BlockType
  blockInfoAttributes: ExtendedBlockInfoAttributes
  attributes: BlockAttributes
  setAttributes: (attrs: Partial<BlockAttributes>) => void
  isCollectionItem?: boolean
}

export const BlockEdit = ({
  blockName,
  blockInfoAttributes,
  attributes,
  setAttributes,
  clientId,
  isCollectionItem,
}: BlockEditProps): ReactNode => {
  const blockPropsHook = useBlockProps({ className: "block" })
  const { setSelectedBlock } = dispatch(ZILCH_EDITOR_STORE) as ZilchEditorActions

  const { updateBlockAttributes } = dispatch("core/block-editor") as any

  const selectedBlockId = useSelect(
    select => {
      const { getSelectedBlock } = select(ZILCH_EDITOR_STORE) as any
      return getSelectedBlock()
    },
    [clientId]
  )

  const isSelected = clientId === selectedBlockId

  const customBlockProps = {
    "data-title": attributes.section || blockName,
  }

  const blockProps = !isCollectionItem
    ? {
        ...blockPropsHook,
        ...customBlockProps,
      }
    : { className: isSelected ? "is-selected" : "", ...customBlockProps }

  useEffect(() => {
    updateBlockAttributes(clientId, {
      lock: {
        move: true,
        remove: true,
      },
    })
  }, [clientId])

  const innerBlockAttributes: ExtendedBlockInfoAttributes = Object.fromEntries(
    Object.entries(blockInfoAttributes).filter(([blockAttributeName]) => isInnerBlockAttribute(blockAttributeName))
  )

  const sortedAttributes = sortAttributes(blockInfoAttributes).filter(
    ([blockAttributeName, blockAttribute]) =>
      !blockAttribute.hidden && !isInnerBlockAttribute(blockAttributeName) && !isSecondaryOrTertiary(blockAttributeName)
  )

  const secondaryOrTertiaryAttributes = Object.entries(blockInfoAttributes)
    .filter(([blockAttributeName]) => isSecondaryOrTertiary(blockAttributeName))
    .sort(([a], [b]) => a.localeCompare(b))

  const handleFocusParent = (e: React.FocusEvent): void => {
    e.stopPropagation()
    setSelectedBlock(clientId)
  }

  return (
    <div {...blockProps} onFocus={handleFocusParent} tabIndex={0}>
      {sortedAttributes.length > 0 && (
        <>
          <div className={"content-block"}>
            <div className="content">
              {sortedAttributes
                .filter(([attributeName]) => attributeName !== "image")
                .map(([attributeName, blockAttribute], index) => (
                  <div key={`field-${clientId}-${index}`}>
                    <EditField
                      attributes={attributes}
                      setAttributes={setAttributes}
                      attributeName={attributeName}
                      blockAttribute={blockAttribute}
                    />
                  </div>
                ))}
            </div>
            {sortedAttributes
              .filter(([attributeName]) => attributeName === "image")
              .map(([attributeName, blockAttribute], index) => (
                <div data-title="image" key={`field-${clientId}-${index}`}>
                  <EditField
                    attributes={attributes}
                    setAttributes={setAttributes}
                    attributeName={attributeName}
                    blockAttribute={blockAttribute}
                  />
                </div>
              ))}
          </div>

          {secondaryOrTertiaryAttributes.map(([attributeName], index) => (
            <SupportiveBlock
              key={`${attributeName}-${clientId}-${index}`}
              isSelected={isSelected}
              clientId={clientId}
              setAttributes={setAttributes}
              attributes={attributes}
              attributeName={attributeName}
            />
          ))}
        </>
      )}

      {Object.keys(innerBlockAttributes).length > 0 && (
        <CollectionEdit
          setAttributes={(blockAttributes: any): void => {
            setAttributes({ PrimaryBlocks: [...blockAttributes] })
          }}
          parentBlockName={blockName}
          clientId={clientId}
          blockInfoAttributes={innerBlockAttributes}
          innerBlockItems={attributes.PrimaryBlocks}
        />
      )}
    </div>
  )
}

export function getBlockEdit(blockName: string, type: BlockType, blockInfoAttributes: ExtendedBlockInfoAttributes) {
  return ({ attributes, setAttributes, clientId }: WpBlockEditProps<BlockAttributes>): ReactNode => (
    <BlockEdit
      clientId={clientId}
      blockName={blockName}
      blockType={type}
      blockInfoAttributes={blockInfoAttributes}
      attributes={attributes}
      setAttributes={setAttributes}
    />
  )
}
