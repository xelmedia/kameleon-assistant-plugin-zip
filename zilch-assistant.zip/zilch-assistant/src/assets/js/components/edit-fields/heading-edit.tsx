import React, { ReactNode } from "react"
import { RichText } from "@wordpress/block-editor"
import { decodeEntities } from "@wordpress/html-entities"
import { HeadingLevelDropdown } from "../heading-level-dropdown"

export const HeadingEdit = ({ attributes, setAttributes, attributeName }): ReactNode => {
  const attributeValue = attributes[attributeName]

  const title = attributeValue || { heading: "h2", content: "" }

  const { heading, content } = title
  const currentValue = decodeEntities(content)

  return (
    <div className={"heading-edit-field"}>
      <RichText
        label={attributeName}
        tagName={heading}
        value={currentValue}
        className={content?.length > 0 ? "" : "has-placeholder"}
        placeholder={`Vul een ${attributeName} in`}
        onChange={(newContent): void => setAttributes({ [attributeName]: { heading, content: newContent } })}
        allowedFormats={["core/bold", "core/italic"]}
      />

      {content?.length > 0 && (
        <HeadingLevelDropdown
          value={heading?.replace(/^h/i, "")}
          onChange={(value): void =>
            setAttributes({
              [attributeName]: {
                heading: `h${value}`,
                content,
              },
            })
          }
        />
      )}
    </div>
  )
}
