import React, { ReactNode, useEffect, useState } from "react"
import { MediaUpload } from "@wordpress/media-utils"
import { select, useSelect } from "@wordpress/data"
import { BlockAttributes } from "@wordpress/blocks"
import { MediaUploadCheck } from "@wordpress/block-editor"
import { Button } from "@wordpress/components"
import { Icon, trash } from "@wordpress/icons"
import { ZilchEditorSettings } from "../../types/wordpress__editor"

export type MediaAttributeValue = {
  url: string
  id: number
  alt: string
}

type MediaEditProps = {
  attributes: BlockAttributes
  setAttributes: (attrs: Partial<BlockAttributes>) => void
  attributeName: string
}

export const mediaSizing = (attributes: BlockAttributes, attributeName: string): MediaAttributeValue[] =>
  useSelect(() => {
    const imageValues: MediaAttributeValue[] = attributes[attributeName] as MediaAttributeValue[]

    if (imageValues && imageValues.length > 0) {
      const { getMedia } = select("core")

      return imageValues.map(imageValue => {
        const image = getMedia(imageValue.id)
        if (!image) return imageValue

        const imageSizes = image?.media_details?.sizes
        const previewSize = imageSizes?.medium || imageSizes?.thumbnail || imageSizes?.full || image
        return { url: previewSize?.source_url, alt: image?.alt_text, id: image?.id }
      })
    }
    return []
  }, [attributes, attributeName])

export const MediaEdit: React.FC<MediaEditProps> = ({ attributes, setAttributes, attributeName }): ReactNode => {
  const mediaAttribute: MediaAttributeValue = attributes[attributeName] as MediaAttributeValue
  const [previewMedia, setPreviewMedia] = useState(mediaAttribute?.[0])
  const { getEditorSettings } = select("core/editor")
  const { pluginUrl } = getEditorSettings() as ZilchEditorSettings

  const onSelectMedia = (media: { url?: string; id?: number; alt?: string }): void => {
    setAttributes({
      [attributeName]: {
        url: media?.url,
        id: media?.id,
        alt: media?.alt,
      },
    })
  }

  useEffect(() => {
    const media: MediaAttributeValue = attributes[attributeName] as MediaAttributeValue
    setPreviewMedia(media)
  }, [attributes, attributeName])

  return (
    <MediaUploadCheck>
      <MediaUpload
        onSelect={onSelectMedia}
        value={previewMedia?.id}
        render={({ open }): ReactNode => {
          const className = !previewMedia ? "block-editor-media has-placeholder" : "block-editor-media"

          return (
            <div className={className}>
              <img
                width="100%"
                onClick={open}
                src={previewMedia?.url || (pluginUrl && `${pluginUrl}/build/assets/placeholder-image.png`)}
                alt={previewMedia?.alt || ""}
              />
              {!previewMedia && <p>Voeg een afbeelding toe</p>}

              {previewMedia && (
                <Button isDestructive className={"delete"} onClick={(): void => setAttributes({ [attributeName]: [] })}>
                  <Icon icon={trash} />
                </Button>
              )}
            </div>
          )
        }}
      />
    </MediaUploadCheck>
  )
}
