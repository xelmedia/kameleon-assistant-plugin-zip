import React, { FC, ReactElement, useEffect, useRef, useState } from "react"
import { Button, Popover, ToolbarDropdownMenu, Tooltip } from "@wordpress/components"
import { RichText, URLInputButton } from "@wordpress/block-editor"
import { __ } from "@wordpress/i18n"
import { button as buttonIcon, chevronRight, Icon, plus, trash } from "@wordpress/icons"
import { LayoutPropTypes } from "@kameleon-core/types"
import { BlockAttributes } from "@wordpress/blocks"

type ButtonEditType = {
  setAttributes: (attrs: Partial<BlockAttributes>) => void
  attributes: BlockAttributes
  attributeName: string
  maxLength: number
}

export const ButtonEdit: FC<ButtonEditType> = ({
  setAttributes,
  attributes,
  attributeName,
  maxLength,
}): ReactElement => {
  const [activePopoverIndex, setActivePopoverIndex] = useState<number | null>(null)
  const buttonRefs = useRef<Record<number, HTMLElement>>({})
  const addingNewButtonRef = useRef(false)

  const attributeValue =
    typeof attributes[attributeName] === "string" || !attributes[attributeName] ? [] : attributes[attributeName]
  const buttons: LayoutPropTypes.ButtonProps[] = Array.isArray(attributeValue) ? attributeValue : [attributeValue]
  const openPopover = (index: number): void => {
    setActivePopoverIndex(index)
  }
  useEffect((): void => {
    if (addingNewButtonRef.current) {
      openPopover(buttons.length - 1)
      addingNewButtonRef.current = false
    }
  }, [buttons])

  const addButton = (): void => {
    const newButton = { text: "", link: "", buttonType: LayoutPropTypes.ButtonType.Primary }
    const newButtons = [...(buttons ?? []), newButton]
    setAttributes({ [attributeName]: newButtons })

    addingNewButtonRef.current = true
  }

  const closePopover = (): void => {
    setActivePopoverIndex(null)
  }

  const updateButton = (index: number, key: string, value: string): void => {
    const updatedButtons = [...buttons]
    updatedButtons[index][key] = value
    setAttributes({ [attributeName]: updatedButtons })
  }

  const removeButton = (index: number): void => {
    const updatedButtons = buttons.filter((_, i) => i !== index)
    setAttributes({ [attributeName]: updatedButtons })
    closePopover()
  }

  return (
    <div className="button-edit-preview">
      <div className="button-items">
        {buttons?.length === 0 && (
          <Button className="components-button button-placeholder" onClick={addButton}>
            Knop toevoegen <Icon icon={plus} />
          </Button>
        )}
        {buttons?.map((button, index) => (
          <Button
            key={`button-${index}`}
            className={`components-button button-${button.buttonType?.toLowerCase()}`}
            data-button-type={button.buttonType}
            ref={(el): any => {
              if (el) buttonRefs.current[index] = el
            }}
            data-link={button.link}
            onClick={(): void => openPopover(index)} // Open popover on button click
          >
            <RichText
              key={`edit-button-${attributeName}-${index}`}
              value={button.text}
              label={attributeName}
              onKeyDown={(event): void => {
                if (event.key === "Enter") {
                  event.preventDefault()
                }
              }}
              allowedFormats={[]}
              onFocus={(): void => openPopover(index)} // Ensure popover opens on focus
              onChange={(value): void => updateButton(index, "text", value)}
              placeholder={__("Vul knop tekst in", "zilch")}
            />
            {button.buttonType === LayoutPropTypes.ButtonType.Tertiary && <Icon icon={chevronRight} />}
          </Button>
        ))}
      </div>

      {buttons?.length > 0 && buttons?.length < maxLength && maxLength > 1 && (
        <Button isPrimary onClick={addButton} className={"add-new-button"}>
          <Icon icon={plus} size={16} />
        </Button>
      )}

      {activePopoverIndex !== null && buttons?.length > 0 && (
        <Popover
          position="top right"
          className="button-popover"
          focusOnMount={false}
          onClose={closePopover}
          anchor={buttonRefs.current[activePopoverIndex]}
        >
          <ToolbarDropdownMenu
            className={"button-dropdown"}
            label={"Type"}
            icon={<Icon icon={buttonIcon} />}
            controls={Object.entries(LayoutPropTypes.ButtonType).map(([, value]) => ({
              onClick: (): void => {
                updateButton(activePopoverIndex, "buttonType", value)
              },
              title: __(value, "zilch"),
              isActive: value === buttons[activePopoverIndex]?.buttonType,
            }))}
          />

          <URLInputButton
            key={`activeButtonIndex--${activePopoverIndex}}`}
            url={buttons?.[activePopoverIndex].link}
            onChange={(newLink): void => {
              updateButton(activePopoverIndex, "link", newLink)
            }}
          />

          <Tooltip text="Verwijderen">
            <Button icon={<Icon icon={trash} />} onClick={(): void => removeButton(activePopoverIndex)} isDestructive />
          </Tooltip>
        </Popover>
      )}
    </div>
  )
}
