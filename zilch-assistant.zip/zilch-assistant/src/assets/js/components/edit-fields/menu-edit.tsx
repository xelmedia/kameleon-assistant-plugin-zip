import React, { ReactNode, useEffect, useState } from "react"
import { BlockAttributes } from "@wordpress/blocks"
import { SelectControl } from "@wordpress/components"
import { getMenus } from "../../blocks/menus"

type MenuEditProps = {
  attributes: BlockAttributes
  setAttributes: (attrs: Partial<BlockAttributes>) => void
  attributeName: string
}

type MenuState = { label: string; value: string }

const resolveMenuOptions = async (): Promise<MenuState[]> => {
  let jsonMenu = await getMenus()
  if (typeof jsonMenu === "string") {
    jsonMenu = JSON.parse(jsonMenu)
  }
  return jsonMenu.map((menu: { name: string; slug: string }) => ({ label: menu.name, value: menu.slug }))
}

const chooseMenuOption = { label: "Kies een menu", value: "" }

export const MenuEdit = ({ attributes, setAttributes, attributeName }: MenuEditProps): ReactNode => {
  const [menuOptions, setMenuOptions] = useState([chooseMenuOption])

  useEffect(() => {
    resolveMenuOptions().then(options => setMenuOptions([chooseMenuOption, ...options]))
  }, [])

  return (
    <SelectControl
      label={"MENU"}
      data-title={attributeName}
      value={attributes[attributeName]}
      options={menuOptions}
      onChange={(value: string): void => {
        setAttributes({ [attributeName]: value })
      }}
    />
  )
}
