import { BlockInfoAttribute } from "@kameleon-core/types"
import React, { ReactNode, useState } from "react"
import { decodeEntities } from "@wordpress/html-entities"
import { __ } from "@wordpress/i18n"
import { InspectorControls, RichText } from "@wordpress/block-editor"
import { Notice } from "@wordpress/components"
import { Icon, warning } from "@wordpress/icons"
import { BlockAttributes } from "@wordpress/blocks"

type EditFieldProps = {
  attributeName: string
  blockAttribute: BlockInfoAttribute
  attributes: BlockAttributes
  setAttributes: (attrs: Partial<BlockAttributes>) => void
}

export const RichTextEdit = ({
  attributeName,
  blockAttribute,
  setAttributes,
  attributes,
}: EditFieldProps): ReactNode => {
  const [message, setMessage] = useState(null)
  const content = attributes[attributeName]
  const currentValue = decodeEntities(attributes[attributeName] || "")

  const MAX_LENGTH = blockAttribute.maxLength
  const WARNING_LENGTH = Math.floor(MAX_LENGTH * 0.75)
  const onChangeContent = (newContent): void => {
    if (newContent.length <= MAX_LENGTH || !MAX_LENGTH) {
      setAttributes({ [attributeName]: newContent })

      if (newContent.length >= WARNING_LENGTH && newContent.length < MAX_LENGTH) {
        setMessage({
          type: "warning",
          text: __("You are close to the character limit!"),
        })
      } else if (newContent.length < WARNING_LENGTH) {
        setMessage(null)
      }
    } else {
      setMessage({
        type: "error",
        text: __("Character limit exceeded!"),
      })
    }
  }

  return (
    <>
      <InspectorControls>
        {message && (
          <Notice status={message.type === "error" ? "error" : "warning"} isDismissible={false}>
            {message.text}
          </Notice>
        )}
      </InspectorControls>

      <RichText
        label={attributeName}
        maxLength={blockAttribute.maxLength}
        value={currentValue}
        className={currentValue.length === 0 ? "has-placeholder" : ""}
        placeholder={`Vul een ${attributeName} in`}
        onChange={onChangeContent}
        allowedFormats={["core/bold", "core/italic", "core/link"]}
      />

      {MAX_LENGTH && message && (
        <div className="character-count">
          <Icon icon={warning} className={`character-count__icon character-count__icon--warning ${message.type}`} />

          <p className={`character-count__text character-count__text--${message.type}`}>
            {`${content ? content.length : 0}/${MAX_LENGTH}`}
          </p>
        </div>
      )}
    </>
  )
}
