import { select, useSelect } from "@wordpress/data"
import React, { ReactNode, useEffect, useState } from "react"
import { InspectorControls } from "@wordpress/block-editor"
import { BlockAttributes } from "@wordpress/blocks"
import { PanelBody, SelectControl } from "@wordpress/components"
import { getEmptyAttributes, getZilchBlock, getZilchBlocks, lowerFirst } from "../../utils"
import { BlockEdit } from "../block-edit"

type BlockEditProps = {
  attributeName: string
  clientId?: string
  isSelected: boolean
  preSelectedBlock?: string
  attributes: BlockAttributes
  setAttributes: (attrs: Partial<BlockAttributes>) => void
}

export const SupportiveBlock = ({
  isSelected,
  attributeName,
  setAttributes,
  attributes,
  clientId,
}: BlockEditProps): ReactNode => {
  const [selectedBlock, setSelectedBlock] = useState<string>("")

  useEffect(() => {
    if (!attributes[attributeName]) {
      setSelectedBlock("")
    } else {
      setSelectedBlock(attributes[attributeName].name)
    }
  }, [attributes[attributeName], clientId])

  const blockInfo = useSelect(
    (s: typeof select) => {
      const { getSelectedBlock } = s("core/block-editor")
      const currentBlock = getSelectedBlock()

      if (!currentBlock) {
        return null
      }

      return getZilchBlock(currentBlock.name).zilchBlockInfo
    },
    [clientId]
  )

  const blocks = getZilchBlocks().filter(block => {
    const blockSizeAttr = `${lowerFirst(attributeName)}Size`
    const blockType = `${block.zilchBlockInfo?.blockType}Block`
    const blockSize = blockInfo?.[blockSizeAttr]
    const isEligible =
      typeof block.zilchBlockInfo?.[blockSizeAttr] === "string"
        ? blockSize === block.zilchBlockInfo?.[blockSizeAttr]
        : block.zilchBlockInfo?.[blockSizeAttr]?.includes(blockSize)

    return attributeName === blockType && isEligible
  })

  const handleSelectBlock = (value: string): void => {
    setSelectedBlock(value)
    const newBlockType = getZilchBlock(value)

    let blockAttributes

    if (newBlockType) {
      blockAttributes = {
        name: newBlockType.name,
        packageName: newBlockType.zilchBlockInfo.name,
        attributes: getEmptyAttributes(newBlockType.zilchBlockInfo),
      }
    }

    setAttributes({ [attributeName]: blockAttributes })
  }

  const onSetAttribute = (value: Record<string, any>): void => {
    setAttributes({ [attributeName]: { ...attributes[attributeName], ...value } })
  }

  const currentBlockType = getZilchBlock(selectedBlock)

  const currentBlock = attributes[attributeName]
  const currentBlockAttributes = currentBlock?.attributes || {}

  return (
    <>
      {blocks.length > 0 && isSelected && (
        <InspectorControls>
          <PanelBody title={attributeName} initialOpen={true}>
            <SelectControl
              label="Kies een blok"
              data-title={attributeName}
              value={selectedBlock}
              options={[
                { label: "Geen", value: "" },
                ...blocks.map(block => ({
                  label: block.title,
                  value: block.name,
                })),
              ]}
              onChange={(value: string): void => handleSelectBlock(value)}
            />
          </PanelBody>
        </InspectorControls>
      )}
      {currentBlockType && (
        <BlockEdit
          blockName={attributeName}
          clientId={clientId}
          blockType={currentBlockType.zilchBlockInfo.blockType}
          blockInfoAttributes={currentBlockType.zilchBlockInfo.attributes}
          attributes={currentBlockAttributes}
          isCollectionItem={true}
          setAttributes={(value: Record<string, any>): void => {
            onSetAttribute({ attributes: { ...currentBlockAttributes, ...value } })
          }}
        />
      )}
    </>
  )
}
