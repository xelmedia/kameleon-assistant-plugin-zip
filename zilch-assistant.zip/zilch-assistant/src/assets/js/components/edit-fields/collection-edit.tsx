import React, { ReactNode, useState } from "react"
import { BlockAttributes } from "@wordpress/blocks"
import { BlockType } from "@kameleon-core/types"
import { Button, ButtonGroup } from "@wordpress/components"
import { dispatch } from "@wordpress/data"
import { Icon, plus, trash } from "@wordpress/icons"
import { getEmptyAttributes } from "../../utils"
import { ExtendedBlockInfoAttributes } from "../../blocks"
import { BlockEdit } from "../block-edit"
import { ZILCH_EDITOR_STORE, ZilchEditorActions } from "../../redux/editor/zilch-editor-store"

type CollectionBlockEditProps = {
  blockInfoAttributes: ExtendedBlockInfoAttributes
  setAttributes: (attrs: Partial<BlockAttributes>) => void
  clientId: string
  parentBlockName: string
  innerBlockItems: any[]
}

export const CollectionEdit = ({
  parentBlockName,
  clientId,
  blockInfoAttributes,
  innerBlockItems,
  setAttributes,
}: CollectionBlockEditProps): ReactNode => {
  const blockInfo = blockInfoAttributes.PrimaryBlocks.items
  const { attributes } = blockInfo
  const primaryBlocks = innerBlockItems ?? []

  const [activeTab, setActiveTab] = useState(0)
  const currentBlock = primaryBlocks[activeTab]
  const itemClientId = `${clientId}-${activeTab}`

  const buttons = primaryBlocks.map((block, index) => (
    <Button
      key={block.clientId}
      variant={activeTab === index ? "primary" : "secondary"}
      onClick={(): void => setActiveTab(index)}
    >
      {`${index + 1}`}
    </Button>
  ))

  const handleDeleteBlock = (): void => {
    const newBlocks = primaryBlocks.filter((_, index) => index !== activeTab)
    setAttributes(newBlocks)
    setActiveTab(activeTab === 0 ? 0 : activeTab - 1)
  }

  const handleInsertBlock = (): void => {
    const newBlock = getEmptyAttributes(blockInfoAttributes.PrimaryBlocks.items)
    const newBlocks = [...primaryBlocks, newBlock]
    setAttributes(newBlocks)
    setActiveTab(newBlocks.length - 1)
  }

  const handleUpdateBlock = (value: any): void => {
    const newBlocks = primaryBlocks.map((block, index) => (index === activeTab ? { ...block, ...value } : block))
    setAttributes(newBlocks)
  }
  const { setSelectedBlock } = dispatch(ZILCH_EDITOR_STORE) as ZilchEditorActions

  const handleFocusParent = (e: React.FocusEvent): void => {
    e.stopPropagation()
    setSelectedBlock(itemClientId)
  }

  return (
    <div className="block-editor-inner-blocks" tabIndex={0} onFocus={handleFocusParent} data-title={"PrimaryBlocks"}>
      <div className="collection-tabs">
        <label>Items</label>
        <ButtonGroup>
          <div className={"select-inner-block"}>{buttons}</div>

          <Button onClick={(): void => handleInsertBlock()} className={"add-inner-block"}>
            <Icon size={16} icon={plus} />
          </Button>
        </ButtonGroup>
      </div>

      {currentBlock && (
        <div className="inner-block">
          <BlockEdit
            blockName={`${parentBlockName}-collection`}
            clientId={itemClientId}
            blockType={BlockType.Primary}
            blockInfoAttributes={attributes}
            attributes={currentBlock}
            isCollectionItem={true}
            setAttributes={handleUpdateBlock}
          />

          <Button isDestructive className={"delete-block"} onClick={(): void => handleDeleteBlock()}>
            <Icon icon={trash} />
          </Button>
        </div>
      )}
    </div>
  )
}
