import { BlockInfoAttribute } from "@kameleon-core/types"
import React, { ReactNode } from "react"
import { Button } from "@wordpress/components"
import { Icon, plus, lineSolid } from "@wordpress/icons"
import { BlockAttributes } from "@wordpress/blocks"
import { EditField } from "../edit-field"
import { sortAttributes } from "../../utils"

type EditFieldProps = {
  attributeName: string
  blockAttribute: BlockInfoAttribute
  attributes: BlockAttributes
  setAttributes: (attrs: Partial<BlockAttributes>) => void
}

export const ItemsEdit = ({ attributeName, blockAttribute, setAttributes, attributes }: EditFieldProps): ReactNode => {
  const items = attributes[attributeName] || []

  const saveContent = (key: number, value: any): void => {
    const newItems = [...items]
    newItems[key] = { ...newItems[key], ...value }

    setAttributes({ [attributeName]: newItems })
  }

  const addItem = (): void => {
    const newItem = {}

    Object.keys(blockAttribute.items.attributes).forEach(key => {
      newItem[key] = ""
    })
    const newItems = [...items, newItem]

    setAttributes({ [attributeName]: newItems })
  }

  const deleteItem = (key): void => {
    const newItems = [...items]
    newItems.splice(key, 1)

    setAttributes({ [attributeName]: newItems })
  }

  return (
    <div className="items-block-wrapper" data-title={attributeName}>
      {items?.map((item, key) => (
        <div key={`item-block-${attributeName}-${key}`} className="item-block">
          <Button onClick={(): void => deleteItem(key)} className={"item-block--remove"}>
            <Icon size={14} icon={lineSolid} />
          </Button>

          <div className="item-block--fields">
            {sortAttributes(blockAttribute.items.attributes).map(([fieldName], fieldKey) => (
              <EditField
                key={`item-block-${fieldName}-${fieldKey}`}
                setAttributes={(newValue): void => saveContent(key, newValue)}
                attributes={item}
                attributeName={fieldName}
                blockAttribute={blockAttribute.items.attributes[fieldName]}
              />
            ))}
          </div>
        </div>
      ))}

      <Button onClick={addItem} className={"item-block--add"}>
        <Icon size={18} icon={plus} />
        Item toevoegen
      </Button>
    </div>
  )
}
