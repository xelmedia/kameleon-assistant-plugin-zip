/* eslint-disable @typescript-eslint/no-empty-function */
import React, { ReactElement, ReactNode, useEffect } from "react"
import { MediaUpload, MediaUploadCheck } from "@wordpress/block-editor"
import { BlockAttributes } from "@wordpress/blocks"
import { select, useDispatch } from "@wordpress/data"
import { mediaSizing } from "./media-edit"
import { ZilchEditorSettings } from "../../types/wordpress__editor"

export type MediaAttributeValue = {
  url: string
  id: number
  alt: string
}

type MediaEditProps = {
  attributes: BlockAttributes
  setAttributes: (attrs: Partial<BlockAttributes>) => void
  attributeName: string
}

export const MediaArrayEdit = ({ attributes, setAttributes, attributeName }: MediaEditProps): ReactNode => {
  const mediaAttributeValues = mediaSizing(attributes, attributeName)
  const { updateSettings } = useDispatch("core/block-editor")
  const { getEditorSettings } = select("core/editor")

  const { pluginUrl } = getEditorSettings() as ZilchEditorSettings

  useEffect(() => {
    updateSettings({
      mediaUpload: () => MediaUpload,
    })
  }, [])

  const Gallery = ({ previews, onClick }): ReactNode => {
    const limitedPreviews = previews.slice(0, 5)

    const className = limitedPreviews.length === 2 ? "gallery-flex" : "gallery-grid"
    return (
      <div
        className={`gallery ${className} ${limitedPreviews.length === 0 ? "has-placeholder" : ""}`}
        onClick={onClick}
      >
        {limitedPreviews.map((preview, index) => (
          <div key={index} className={`gallery-item block-editor-media ${index === 0 ? "large" : ""}`}>
            <img src={preview?.url || ""} alt={preview?.alt || ""} />

            {index === 4 && previews.length > 5 && <span className={"more-items"}>{previews.length - 5}</span>}
          </div>
        ))}

        {limitedPreviews.length === 0 && (
          <div className="block-editor-media">
            <img src={`${pluginUrl}/build/assets/placeholder-image.png`} />
            <p>Voeg hier afbeeldingen toe</p>
          </div>
        )}
      </div>
    )
  }

  return (
    <div data-title={attributeName}>
      <MediaUploadCheck>
        <MediaUpload
          gallery={true}
          multiple="add"
          allowedTypes={["image"]}
          onSelect={(selectedItems): void => {
            const mediaAttributes = selectedItems.map((item: MediaAttributeValue) => ({
              url: item.url,
              id: item.id,
              alt: item.alt,
            }))
            setAttributes({ [attributeName]: mediaAttributes })
          }}
          value={attributes[attributeName]?.map((item: MediaAttributeValue) => item.id)}
          render={({ open }): ReactElement | undefined => <Gallery previews={mediaAttributeValues} onClick={open} />}
        />
      </MediaUploadCheck>
    </div>
  )
}
