import React, { useState, FC, ReactElement, useEffect } from "react"
import { Icon } from "@iconify/react"
import { Button, Popover, TextControl } from "@wordpress/components"
import { select } from "@wordpress/data"
import { getIconifyUrl } from "../../utils"

type IconEditType = {
  setAttribute: (attributeValue: string) => void
  value: string
}

export const IconEdit: FC<IconEditType> = ({ setAttribute, value }): ReactElement => {
  const [isPopoverVisible, setPopoverVisible] = useState(false)
  const [iconOptions, setIconOptions] = useState<string[]>([])
  const [searchTerm, setSearchTerm] = useState("")

  const { getEditorSettings } = select("core/editor")

  useEffect(() => {
    const fetchIcons = async (query: string): Promise<void> => {
      const response = await fetch(getIconifyUrl(query, getEditorSettings().zilchIconPack ?? ""))
      const data: { icons?: string[] } = await response.json()
      if (data.icons) setIconOptions(data.icons)
    }

    if (searchTerm) {
      const handler = setTimeout(() => fetchIcons(searchTerm), 300)
      return () => clearTimeout(handler)
    }

    setIconOptions([])
    return undefined
  }, [searchTerm])

  const handleSearchChange = (changedValue: string): void => setSearchTerm(changedValue)

  const handleIconSelect = (icon: string): void => {
    setAttribute(icon)
    setPopoverVisible(false)
  }

  const hasIcon = value?.length > 0

  return (
    <div className="icon-edit" data-icon={value}>
      <Button
        onClick={(): void => setPopoverVisible(!isPopoverVisible)}
        className={`icon-edit__button icon-edit__button--icon ${!hasIcon ? "icon-edit__button--placeholder" : ""}`}
      >
        {hasIcon && <Icon inline icon={value} />}
      </Button>

      {isPopoverVisible && (
        <Popover
          position="bottom right"
          onClose={(): void => setPopoverVisible(false)}
          onFocusOutside={(): void => setPopoverVisible(false)}
          focusOnMount={false}
        >
          <div className="icon-edit__popover">
            <TextControl
              type="search"
              placeholder="Zoek een icon"
              value={searchTerm}
              onChange={handleSearchChange}
              className="icon-edit__search-input"
            />

            {iconOptions.length > 0 ? (
              <div className="icon-edit__icon-grid">
                {iconOptions.map(icon => {
                  const iconName = icon.split(":")[1]

                  return (
                    <div
                      key={icon}
                      className={`icon-edit__icon-item ${iconName}`}
                      onClick={(): void => handleIconSelect(icon)}
                    >
                      <Icon className="icon-edit__icon" inline icon={icon} />
                    </div>
                  )
                })}
              </div>
            ) : (
              hasIcon && searchTerm.length > 0 && <p className="icon-edit__no-results">Geen iconen gevonden</p>
            )}

            {hasIcon && (
              <Button onClick={(): void => setAttribute("")} className="icon-edit__button icon-edit__button--remove">
                Verwijderen
              </Button>
            )}
          </div>
        </Popover>
      )}
    </div>
  )
}
