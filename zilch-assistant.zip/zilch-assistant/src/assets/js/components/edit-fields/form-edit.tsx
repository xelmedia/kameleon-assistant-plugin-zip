import React, { ReactNode, useEffect, useState } from "react"
import { BlockAttributes } from "@wordpress/blocks"
import { SelectControl } from "@wordpress/components"
import { fetchForms, FormOption } from "../../blocks/forms"

type FormEditProps = {
  attributes: BlockAttributes
  setAttributes: (attrs: Partial<BlockAttributes>) => void
  attributeName: string
}

export const FormEdit = ({ attributes, setAttributes, attributeName }: FormEditProps): ReactNode => {
  const [formOptions, setFormOptions] = useState<FormOption[] | undefined>(undefined)

  useEffect(() => {
    if (formOptions === undefined) {
      fetchForms().then(options => {
        setFormOptions([{ label: "Kies een contact formulier", value: "" }, ...options])
      })
    }
  }, [formOptions])

  return (
    <SelectControl
      label={"Contact Form"}
      value={attributes[attributeName]}
      options={formOptions}
      onChange={(value: string): void => {
        setAttributes({ [attributeName]: value })
      }}
    />
  )
}
