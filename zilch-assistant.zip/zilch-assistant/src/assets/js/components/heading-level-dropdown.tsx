import React, { ReactNode } from "react"
import { ToolbarDropdownMenu } from "@wordpress/components"
import { __, sprintf } from "@wordpress/i18n"
import { Icon, headingLevel2, headingLevel3, headingLevel4, headingLevel5, headingLevel6 } from "@wordpress/icons"

const HEADING_LEVELS = [2, 3, 4, 5, 6]

const POPOVER_PROPS = {
  className: "block-library-heading-level-dropdown",
}

const LEVEL_TO_PATH = {
  2: headingLevel2,
  3: headingLevel3,
  4: headingLevel4,
  5: headingLevel5,
  6: headingLevel6,
}

interface HeadingLevelDropdownProps {
  options?: number[]
  value: number
  onChange: (level: number) => void
}

export const HeadingLevelDropdown = ({
  options = HEADING_LEVELS,
  value,
  onChange,
}: HeadingLevelDropdownProps): ReactNode => {
  const validOptions = options.filter(option => option === 0 || HEADING_LEVELS.includes(option)).sort((a, b) => a - b) // Sorts numerically in ascending order

  return (
    <ToolbarDropdownMenu
      popoverProps={POPOVER_PROPS}
      className={"heading-dropdown"}
      icon={<Icon icon={LEVEL_TO_PATH[value] ?? headingLevel2} />}
      label={__("Change level")}
      controls={validOptions.map(targetLevel => {
        const isActive = targetLevel === value
        return {
          icon: <Icon icon={LEVEL_TO_PATH[targetLevel] ?? headingLevel2} />,
          title: sprintf(__("Heading %d", "zilch-assistant"), targetLevel),
          isActive,
          onClick: (): void => {
            onChange(targetLevel)
          },
          role: "menuitemradio",
        }
      })}
    />
  )
}
