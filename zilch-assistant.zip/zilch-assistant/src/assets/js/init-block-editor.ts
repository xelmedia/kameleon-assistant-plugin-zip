import { register, select } from "@wordpress/data"
import { addAction } from "@wordpress/hooks"
import { blocksRegisteredAction, blocksRegisteredNamespace, editorDisplaySettings } from "./utils"
import { reloadAndRenderBlocks, hookBlockEditorNotices } from "./blocks/block-editor"
import { renderLoadingModal } from "./pages/modal"
import { zilchEditorStore } from "./redux/editor/zilch-editor-store"

export async function initBlockEditor(): Promise<void> {
  const handleBlocksRegistered = async (): Promise<void> => {
    renderLoadingModal(false)
    const blocks = select("core/block-editor").getBlocks()
    await reloadAndRenderBlocks(blocks)
  }

  register(zilchEditorStore)
  renderLoadingModal()
  hookBlockEditorNotices()
  editorDisplaySettings()

  addAction(blocksRegisteredAction, blocksRegisteredNamespace, async (): Promise<void> => {
    await handleBlocksRegistered()
  })
}

await initBlockEditor()
