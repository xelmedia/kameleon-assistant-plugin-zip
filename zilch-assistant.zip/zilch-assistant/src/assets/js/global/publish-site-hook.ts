import apiFetch from "@wordpress/api-fetch"

export function publishSiteHook(): void {
  const trigger = document.querySelector("#wp-admin-bar-zilch-build-site")

  trigger?.addEventListener("click", event => {
    event.preventDefault()
    publishSite()
  })
}

function publishSite(): void {
  const confirmMessage =
    "Wil je de laatste wijzigingen jouw website publiceren? " +
    "De laatste wijzigingen die je hebt gedaan worden hiermee live gezet." +
    "\n\n" +
    "Let op: Het kan 5-15 minuten duren voordat de wijzigingen zichtbaar zijn op jouw website." +
    "\n\n"

  // eslint-disable-next-line no-restricted-globals,no-alert
  if (confirm(confirmMessage)) {
    // Handle the confirmed action here
    apiFetch({
      path: "/assistant/static-content/build",
      method: "POST",
    })
    // eslint-disable-next-line no-alert
    alert("Je website wordt gepubliceerd! Het kan tot 15 minuten duren voordat de wijzigingen zichtbaar zijn.")
  } else {
    // Handle the canceled action here
    // eslint-disable-next-line no-alert
    alert("Publiceren geannuleerd.")
  }
}

global.publishSite = publishSite
