import { registerBlocks } from "./blocks"
import { disableWelcomeModal } from "./blocks/block-editor"

async function init(): Promise<void> {
  document.body.classList.add("is-loading")
  disableWelcomeModal()
  await registerBlocks()
  document.body.classList.remove("is-loading")
}

await init()
