import { initializeEditor } from "@wordpress/edit-post"
import { addAction } from "@wordpress/hooks"
import { getQueryArg } from "@wordpress/url"
import { dispatch, select } from "@wordpress/data"
import { EditorSettings } from "@wordpress/block-editor"
import { blocksRegisteredAction, blocksRegisteredNamespace, editorDisplaySettings } from "./utils"
import { CustomPostType } from "./types/posts-helper"
import { SettingStoreActions } from "./redux/settings-store-actions"
import { ZILCH_SETTINGS_STORE } from "./redux/settings-store"
import { ZilchEditorSettings } from "./types/wordpress__editor"
import { initBlockEditor } from "./init-block-editor"

declare global {
  interface Window {
    getZilchEditorSettings: ZilchEditorSettings
  }
}

addAction(blocksRegisteredAction, blocksRegisteredNamespace, async () => {
  const { fetchContent } = dispatch(ZILCH_SETTINGS_STORE) as SettingStoreActions
  const { getEditorSettings } = select("core/editor")
  initBlockEditor()

  editorDisplaySettings(false)

  const pageType = getQueryArg(window.location.href, "page") as string
  const settings: EditorSettings = { ...getEditorSettings(), ...window.getZilchEditorSettings }
  await fetchContent(pageType as CustomPostType).then(res => {
    initializeEditor("editor", pageType, res.post.id, settings)
  })
})
