import apiFetch from "@wordpress/api-fetch"
import { BlockInfoAttributes } from "@kameleon-core/types/src/blockinfo/block-info-attributes"
import { getBlockType, getBlockTypes } from "@wordpress/blocks"
import { AttributeType, BlockInfoAttribute, BlockInfoType } from "@kameleon-core/types"
import { ExtendedBlockInfoAttribute } from "./blocks"
import { ZilchBlock } from "./blocks/wp-block-configuration"

export const textDomain = "zilch-assistant"

const { wp } = global as any

export function getWpNonce(): string {
  // wpApiSettingsNonce will get overwritten by auth0 plugin that sets own nonce, when "rolling sessions" are enabled.
  // eslint-disable-next-line @typescript-eslint/ban-ts-comment
  // @ts-ignore
  return (apiFetch as any)?.nonceMiddleware?.nonce ?? wpApiSettings.nonce
}

export function getBaseUrl(): string {
  return window.location.origin
}

export function getIconifyUrl(query: string, iconPack: string): string {
  return `https://iconify.kameleon-webservices.nl/search?query=${query}&limit=999&prefix=${iconPack}`
}

// Blocks registered action is triggered after blocks are registered.
// A doAction is triggered within the register pages
export const blocksRegisteredAction = "blocksRegistered"
export const blocksRegisteredNamespace = "kameleon/assistant/blocks-registered"

export function getEnumKeyByEnumValue<T extends { [index: string]: string }>(
  myEnum: T,
  enumValue: string
): string | null {
  const keys = Object.keys(myEnum).filter(x => myEnum[x] === enumValue)
  return keys.length > 0 ? keys[0] : null
}

export function sortAttributes(attributes: BlockInfoAttributes): [string, ExtendedBlockInfoAttribute][] {
  const desiredOrder = [
    "icon",
    "image",
    "number",
    "quote",
    "name",
    "tagline",
    "tag",
    "subTag",
    "header",
    "title",
    "tabTitle",
    "subject",
    "description",
    "text",
    "content",
    "items",
    "points",
    "statistics",
    "button",
  ]

  return (
    Object.entries(attributes)
      .filter(([attributeName]) => attributeName !== "layoutOptions")
      // Sort entries according to the custom order
      .sort(([a], [b]) => {
        // Get the index of the attribute in the desired order, or push to the end if not found
        const indexA = desiredOrder.indexOf(a) !== -1 ? desiredOrder.indexOf(a) : Infinity
        const indexB = desiredOrder.indexOf(b) !== -1 ? desiredOrder.indexOf(b) : Infinity
        return indexA - indexB
      })
  )
}

export function editorDisplaySettings(fullScreen = true): void {
  const { toggleFeature } = wp.data.dispatch("core/edit-post")
  const { removeEditorPanel } = wp.data.dispatch("core/editor")
  const { isFeatureActive } = wp.data.select("core/edit-post")

  if (!isFeatureActive("fixedToolbar")) {
    toggleFeature("fixedToolbar")
  }

  const isFullScreen = isFeatureActive("fullscreenMode")

  if (fullScreen && !isFullScreen) {
    toggleFeature("fullscreenMode")
  }

  if (!fullScreen && isFullScreen) {
    toggleFeature("fullscreenMode")
  }

  removeEditorPanel("discussion-panel")
}

export function lowerFirst(text: string): string {
  return text.charAt(0).toLowerCase() + text.slice(1)
}

export function getZilchBlock(name: string): ZilchBlock | undefined {
  return getBlockType(name)
}

export function getZilchBlocks(): ZilchBlock[] {
  return getBlockTypes() as ZilchBlock[]
}

export const getEmptyAttributes = (blockInfoType: BlockInfoType | BlockInfoAttribute): Record<string, any> => {
  if (!blockInfoType.attributes) {
    return {} as Record<string, any>
  }

  const defaultAttributes = Object.entries(blockInfoType.attributes).reduce(
    (acc, [name, attribute]) => {
      if (attribute.type === AttributeType.Array) {
        acc[name] = []
      } else if (attribute.type === AttributeType.Text || attribute.type === AttributeType.HTML) {
        acc[name] = ""
      } else {
        acc[name] = null
      }

      return acc
    },
    {} as Record<string, any>
  )

  return defaultAttributes
}
