import domReady from "@wordpress/dom-ready"
import { publishSiteHook } from "./global/publish-site-hook"

domReady(async () => {
  publishSiteHook()
})
