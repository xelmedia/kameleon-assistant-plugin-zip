/**
 * TODO: move to a nice place to render and load custom HTML within the WP admin area
 */
function removeSearchParam(param): void {
  const url = new URL(window.location.href)
  url.searchParams.delete(param)

  window.history.replaceState({}, document.title, url.toString())
}

export function renderLoadingModal(show = true): void {
  const modalId = "loadingModal"
  const existingModal = document.getElementById(modalId)
  const searchParams = new URLSearchParams(window.location.search)

  if (!show || searchParams.has("pages_initialized")) {
    if (existingModal) {
      existingModal.remove()
    }

    removeSearchParam("pages_initialized")

    return
  }

  if (existingModal) return

  const modal = document.createElement("div")
  const logo = `${window.getZilchEditorSettings?.pluginUrl}build/assets/zilch-logo-loading.svg`

  modal.id = modalId
  modal.style.cssText = `
    z-index: 99999999;
    display: flex;
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0, 0, 0, 0.5);
    justify-content: center;
    align-items: center;
  `

  modal.innerHTML = `
    <img
        width="160px"
        className="zilch--loading"
        alt="zilch-loading"
        src="${logo}"
      />
  `

  const container = document.getElementById("wpcontent")
  if (container) {
    container.appendChild(modal)
  }
}
