import { IKameleonPage } from "@kameleon-util/manifest"
import { BlockInstance, serialize, parse } from "@wordpress/blocks"
import apiFetch from "@wordpress/api-fetch"
import { ManifestHelper } from "../manifest/manifest-helper"
import { renderLoadingModal } from "./modal"
import { kameleonBlockToBlockInstance } from "../posts/posts-helper"
import { CustomPostType, ZilchOptions } from "../types/posts-helper"
import { settingStoreActions } from "../redux/settings-store-actions"
import { getWpNonce } from "../utils"
import { ensureFromManifest } from "../redux/settings-store-helpers"

const wpApi = (global.wp as any)?.api as any

/**
 * This method will, given a Kameleon Page (from the manifest) and optionally the existing WordPress page,
 * create the serialized content for the existing or new WordPress page to be saved as content.
 *
 * In case of an existing page, the existing blocks present on this pages will be parsed from the raw content
 * and converted to the known blocks that we're registered using the `register-blocks` api.
 *
 * Note that the handling the parse of the raw content and converting it to known blocks rely on the `transform: [from]`
 * handler that is set within the blockType (ref: ./blocks/register-block-helper.txt:
 *
 * Once all the blocks on the existing page are identified, create new blocks that must exist on this page according to
 * the Kameleon Page. If the page has blocks that were already within the page content, enforce updated props/innerBlocks
 * and keep existing values set that where already on the page.
 *
 * New page blocks with "empty" attribute values are being created whenever the block did not exist on the page yet or
 * the page didn't exist at all.
 *
 * At last, while having all the correct (and merged blocks from existing page), we serialize the blocks to raw HTML content
 * again, so it can be saved as raw content on the existing or new page.
 * @param page
 * @param existingPage
 */
function createPageContentWithBlocks(page: IKameleonPage, existingPage: any = undefined): string {
  // Parse the existing page blocks from the page content and index by block name
  const pageContent = existingPage?.attributes?.content?.raw ?? ""
  const pageBlocks: BlockInstance[] = parse(pageContent)

  // Next, rebuild the correct page content with the known blocks in the correct order.
  const blocks = page.blocks
    .map(blockOnPage => kameleonBlockToBlockInstance(blockOnPage, pageBlocks))
    .filter(block => block)

  return serialize(blocks)
}

const isHomepage = (page: any): boolean => {
  const slug = page?.get("slug")?.toLowerCase()
  const title = page?.get("title")?.rendered?.toLowerCase()
  const homepages = ["home", "/"]
  return homepages.includes(slug) || homepages.includes(title)
}

type SetHomePageResult = { isUpdated: boolean; homePageId?: number }
async function setHomePage(pages: any[]): Promise<SetHomePageResult> {
  const settings = new wpApi.models.Settings()
  settings?.endpointModel?.set("nonce", getWpNonce())

  await settings.fetch()
  const frontPageId = settings.get("page_on_front")

  for (let i = 0; i < pages.length; i += 1) {
    const page = pages[i]
    const pageId = page?.id ?? page?.get("id")
    if (pageId && isHomepage(page)) {
      if (frontPageId === pageId) {
        return { isUpdated: false, homePageId: pageId } // already set, nothing updated
      }
      /* eslint-disable no-await-in-loop */
      const updatedSettings = new wpApi.models.Settings()
      settings?.endpointModel?.set("nonce", getWpNonce())

      await updatedSettings.save({
        page_on_front: pageId,
        show_on_front: "page",
      })
      return { isUpdated: true, homePageId: pageId } // updated, so homepage changed or set
    }
  }
  return { isUpdated: false } // No homepage found
}

type EnsurePagesResult = { homePageId: number }

/**
 * Ensure all the pages from the manifest. If a page already exists, update data correctly according to manifest definition
 * Uses the `createPageContentWithBlocks` to create or merge blocks for a new or existing page.
 * @param registeredPages
 * @param manifestPages
 */
async function ensurePages(
  registeredPages: { [key: string]: any },
  manifestPages: IKameleonPage[]
): Promise<EnsurePagesResult> {
  const savedPages: any[] = []
  const savePromises: Promise<any>[] = []

  manifestPages.forEach((manifestPage, i) => {
    const existingRegisteredPage = registeredPages[manifestPage.pageId ?? -1]
    const pageContent = createPageContentWithBlocks(manifestPage, existingRegisteredPage)

    if (existingRegisteredPage !== undefined) {
      existingRegisteredPage.set("status", "publish")
      existingRegisteredPage.set("meta", {
        ...existingRegisteredPage.get("meta"),
        skip_build_trigger: true,
        kameleon_page_id: manifestPage.pageId,
      })
      existingRegisteredPage.set("menu_order", i)
      existingRegisteredPage.set("content", pageContent)

      savePromises.push(existingRegisteredPage.save().then(() => savedPages.push(existingRegisteredPage)))
    } else {
      const newPage = new wpApi.models.Page({
        title: manifestPage.title,
        slug: manifestPage.slug,
        status: "publish",
        menu_order: i,
        content: pageContent,
      })
      newPage.set("meta", {
        ...(newPage.get("meta") ?? {}),
        skip_build_trigger: true,
        kameleon_page_id: manifestPage.pageId,
      })
      newPage?.endpointModel?.set("nonce", getWpNonce())

      savePromises.push(newPage.save().then(() => savedPages.push(newPage)))
    }
  })

  await Promise.all(savePromises)

  const setHomePageResult = await setHomePage(savedPages)
  return {
    homePageId: setHomePageResult.homePageId,
  }
}

/**
 * Delete all the obsolete pages that are no longer in the manifest, given the pageIds that are present in the manifest
 * @param registeredPages
 * @param pageIdsInManifest
 */
async function deleteObsoletePages(
  registeredPages: any[],
  pageIdsInManifest: string[]
): Promise<{ [key: string]: any }> {
  const removePages = []
  const existingPagesIndexedByPageId = {}
  registeredPages.forEach(rp => {
    if (!pageIdsInManifest.includes(rp.get("meta").kameleon_page_id)) {
      removePages.push(rp)
    } else {
      existingPagesIndexedByPageId[rp.get("meta").kameleon_page_id] = rp
    }
  })

  const deletionPromises = removePages.map(async page => {
    const response = await apiFetch({
      path: `/wp/v2/pages/${page.id}?force=true`,
      method: "DELETE",
    })

    return response
  })

  await Promise.all(deletionPromises)
  return existingPagesIndexedByPageId
}

/**
 * Get a pages collection of all pages, fetched using pagination.
 * Result contains all pages.
 */
async function getRegisteredPages(): Promise<any[]> {
  const pagesAPI = new wpApi.collections.Pages()
  pagesAPI?.endpointModel?.set("nonce", getWpNonce())

  await pagesAPI.fetch({
    data: { per_page: 25, context: "edit" },
  })

  let pages = pagesAPI.map(p => p)

  while (await pagesAPI?.hasMore()) {
    /* eslint-disable no-await-in-loop */
    await pagesAPI.more()
    pages = pages.concat(pagesAPI.map(p => p))
  }
  return pages
}

export function renderLoadingPages(): void {
  // Render the loading modal to detect changes
  renderLoadingModal()
}

/**
 * Open home-page edit after registering/updating pages if `openHomePage` param is set.
 * This is required AFTER initialising the manifest, because new pages may be registered.
 * We do this because of: https://wpengine.com/builders/gutenberg-in-headless-wordpress-wpgraphql-gutenberg/
 * @param homePageId
 */

export function openHomePage(homePageId?: number): void {
  const urlParams = new URLSearchParams(window.location.search)
  if (urlParams.get("open_home_page") === "1" && homePageId) {
    const url = new URL(window.location.href)
    url.searchParams.delete("open_home_page")

    window.location.href = `/wp-admin/post.php?post=${homePageId}&action=edit`
  } else {
    const url = new URL(window.location.href)
    url.searchParams.set("pages_initialized", "1")
    window.location.href = url.toString()
  }
}

/**
 * Register all pages according to the pages from the manifest.
 * Fetching existing pages and merges page content/block attributes if already exists.
 */
export async function registerPages(): Promise<void> {
  const manifest = await ManifestHelper.getManifest()
  const manifestPages = manifest.getPages()
  const settings = new wpApi.models.Settings()
  settings?.endpointModel?.set("nonce", getWpNonce())

  await settings.fetch()
  const zilchManifestId = settings.get("zilch_manifest_id")
  const manifestId = manifest.getManifest(false).id

  if (manifestId !== zilchManifestId) {
    renderLoadingPages()

    // Get WP pages
    const registeredPages = await getRegisteredPages()
    const validRegisteredPages = await deleteObsoletePages(
      registeredPages,
      manifestPages.map(p => p.pageId)
    )
    const ensurePagesResult = await ensurePages(validRegisteredPages, manifestPages)

    const zilchSettings = {
      [ZilchOptions.Theme]: manifest.getTheme(),
      [ZilchOptions.Profile]: manifest.getProfile(),
      [ZilchOptions.Manifest]: manifestId,
    }

    const promises: Promise<any>[] = []
    promises.push(ensureFromManifest(CustomPostType.Header))
    promises.push(ensureFromManifest(CustomPostType.Footer))
    promises.push(settingStoreActions.updateSettings(zilchSettings))

    await Promise.all(promises)

    // If the pages list is updated, reload the page, otherwise stop rendering the loading modal
    openHomePage(ensurePagesResult.homePageId)
  }

  renderLoadingModal(false)
}
