import { Post } from "@wordpress/core-data"
import { dispatch } from "@wordpress/data"
import { BlockInstance, rawHandler, serialize } from "@wordpress/blocks"
import { CustomPostType } from "../types/posts-helper"
import { getAndRegisterWpBlockByPostType, getExistingPosts, kameleonBlockToBlockInstance } from "../posts/posts-helper"
import { ManifestHelper } from "../manifest/manifest-helper"
import { SettingStoreActions } from "./settings-store-actions"
import { ZILCH_SETTINGS_STORE } from "./settings-store"
import { WpBlock } from "../blocks/wp-block"

export async function registerHeaderFooterBlock(type: CustomPostType): Promise<WpBlock> {
  return getAndRegisterWpBlockByPostType(type)
}

const postRawContent = (postModel: Post | undefined): string => postModel?.content?.raw ?? ""

export async function ensureFromManifest(postType: CustomPostType): Promise<void> {
  const manifest = await ManifestHelper.loadManifest()

  const { updateContent, deleteObsoleteContent } = dispatch(ZILCH_SETTINGS_STORE) as SettingStoreActions

  const manifestSection = postType === CustomPostType.Header ? manifest.getHeader() : manifest.getFooter()
  await registerHeaderFooterBlock(postType)

  const existingPost = (await getExistingPosts(postType, { kameleon_page_id: manifestSection.sectionId }))?.[0]
  const existingPostId = existingPost?.id

  let currentBlocks: BlockInstance[] = []
  if (existingPost) {
    currentBlocks = rawHandler({ HTML: postRawContent(existingPost) }) ?? []
  }

  const newOrUpdatedContent = kameleonBlockToBlockInstance(manifestSection, currentBlocks)

  if (!newOrUpdatedContent) return

  const rawContent = serialize([newOrUpdatedContent])

  await deleteObsoleteContent(existingPost, postType)
  await updateContent(existingPostId, manifestSection.sectionId, postType, rawContent)
}
