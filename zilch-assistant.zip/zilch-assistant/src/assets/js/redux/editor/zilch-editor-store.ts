import { createReduxStore } from "@wordpress/data"
import { SettingStoreState } from "../settings-store"

export const ZILCH_EDITOR_STORE = "zilch-editor-store"

export interface ZilchEditorStoreState {
  selectedBlock: string
}

export type ZilchEditorSelectors = {
  getSelectedBlock: (state?: SettingStoreState) => string
}

export type ZilchEditorActions = {
  setSelectedBlock: (clientId: string) => {
    type: string
    selectedBlock: string
  }
}

const SET_SELECTED_BLOCK = "SET_SELECTED_BLOCK" as const

const actions: ZilchEditorActions = {
  setSelectedBlock: (clientId: string): ReturnType<(typeof actions)[keyof typeof actions]> => ({
    type: SET_SELECTED_BLOCK,
    selectedBlock: clientId,
  }),
}

const selectors = {
  getSelectedBlock: (state: ZilchEditorStoreState): string => state.selectedBlock,
}

const reducer = (
  state: ZilchEditorStoreState,
  action: ReturnType<(typeof actions)[keyof typeof actions]>
): ZilchEditorStoreState => {
  switch (action.type) {
    case SET_SELECTED_BLOCK:
      return {
        ...state,
        selectedBlock: action.selectedBlock,
      }
    default:
      return state
  }
}

export const zilchEditorStore = createReduxStore(ZILCH_EDITOR_STORE, {
  reducer,
  actions,
  selectors,
  initialState: {
    selectedBlock: "",
  },
})
