import { Post } from "@wordpress/core-data"
import { SettingStoreState } from "./settings-store"

export type SettingStoreSelectors = {
  getHeaderPost: (state?: SettingStoreState) => Post | null
  getFooterPost: (state?: SettingStoreState) => Post | null
}

export const settingStoreSelectors: SettingStoreSelectors = {
  getHeaderPost(state: SettingStoreState) {
    return state.headerPost
  },
  getFooterPost(state: SettingStoreState) {
    return state.footerPost
  },
}
