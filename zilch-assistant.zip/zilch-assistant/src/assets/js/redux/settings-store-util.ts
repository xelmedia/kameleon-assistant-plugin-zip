import { useSelect } from "@wordpress/data"

export function useTotalInnerBlocks(clientId): number {
  return useSelect(
    select => {
      const { getBlockOrder } = select("core/block-editor")
      return (getBlockOrder as any)?.(clientId).length
    },
    [clientId]
  )
}
