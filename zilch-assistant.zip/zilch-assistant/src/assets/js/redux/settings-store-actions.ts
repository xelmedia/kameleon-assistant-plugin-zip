import { Post } from "@wordpress/core-data"
import apiFetch from "@wordpress/api-fetch"
import axios from "axios"
import { getExistingPosts } from "../posts/posts-helper"
import { CustomPostType } from "../types/posts-helper"

export interface HeaderAction {
  type: string
  post?: Post | null
}

export type SettingStoreActions = {
  fetchContent: (postType: CustomPostType, postId?: number) => Promise<HeaderAction>
  updateContent: (
    postId: number,
    kameleonPageId: string,
    postType: CustomPostType,
    serializedContent: string,
    skipBuild?: boolean
  ) => Promise<HeaderAction>
  deleteObsoleteContent: (existingPost: Post, postType: CustomPostType) => Promise<void>
  updateSettings: (zilchSettings: any) => Promise<void>
}

export const settingStoreActions: SettingStoreActions = {
  async fetchContent(postType: CustomPostType, postId?: number): Promise<HeaderAction> {
    try {
      const postIdParam = postId ? `?post_id=${postId}` : ""
      const response: any = await apiFetch({
        path: `/wp/v2/${postType}${postIdParam}?context=edit`,
        method: "GET",
      })

      const post = Array.isArray(response) && response.length > 0 ? response[0] : null

      return { type: postType, post }
    } catch (error) {
      return { type: "error", post: undefined }
    }
  },
  async updateContent(
    postId: number | undefined,
    kameleonPageId: string,
    postType: CustomPostType,
    serializedContent: string,
    skipBuild = false
  ): Promise<HeaderAction> {
    const url = postId ? `/wp/v2/${postType}/${postId}` : `/wp/v2/${postType}`
    const response: any = await apiFetch({
      path: url,
      method: postId ? "PUT" : "POST",
      data: {
        status: "publish",
        content: serializedContent,
        title: postType,
        meta: {
          skip_build_trigger: skipBuild,
          kameleon_page_id: kameleonPageId,
        },
      },
    })

    return { type: "zilch_header_updated", post: response }
  },
  async deleteObsoleteContent(existingPost: Post | undefined, postType: CustomPostType): Promise<void> {
    const existingPosts = await getExistingPosts(postType, {})
    const existingPostId = existingPost?.id

    if (existingPosts?.length > 0) {
      const promises: Promise<any>[] = existingPosts
        .filter(ef => ef.id !== existingPostId)
        .map(ef => apiFetch({ path: `/wp/v2/${postType}/${ef.id}`, method: "DELETE" }).catch())

      await axios.all(promises)
    }
  },
  async updateSettings(zilchSettings): Promise<void> {
    await apiFetch({
      path: "/assistant/settings",
      method: "POST",
      data: zilchSettings,
    })
  },
}
