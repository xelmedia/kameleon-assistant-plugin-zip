import { createReduxStore } from "@wordpress/data"
import { Post } from "@wordpress/core-data"
import { CustomPostType } from "../types/posts-helper"
import { HeaderAction, settingStoreActions, SettingStoreActions } from "./settings-store-actions"
import { settingStoreSelectors, SettingStoreSelectors } from "./settings-store-selectors"

export const ZILCH_SETTINGS_STORE = "zilch-settings-store"

export interface SettingStoreState {
  headerPost: Post | null
  footerPost: Post | null
  error?: boolean
}

export const settingStore = createReduxStore<SettingStoreState, SettingStoreActions, SettingStoreSelectors>(
  ZILCH_SETTINGS_STORE,
  {
    initialState: <SettingStoreState>{
      headerPost: null,
      footerPost: null,
      error: false,
    },
    reducer(state: SettingStoreState, action: HeaderAction): SettingStoreState {
      switch (action.type) {
        case CustomPostType.Header:
        case CustomPostType.Footer: {
          const key = action.type === CustomPostType.Header ? "headerPost" : "footerPost"
          return { ...state, [key]: action.post }
        }
        case "error":
          return { ...state, error: true }
        default:
          return state
      }
    },
    actions: settingStoreActions,
    selectors: settingStoreSelectors,
  }
)
