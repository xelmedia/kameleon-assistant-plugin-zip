import apiFetch from "@wordpress/api-fetch"

export async function getMenus(): Promise<any> {
  const response = await apiFetch({
    path: `/assistant/menus`,
    method: "GET",
  })

  return response
}
