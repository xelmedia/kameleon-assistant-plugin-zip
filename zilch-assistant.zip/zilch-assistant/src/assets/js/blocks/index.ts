import { doAction } from "@wordpress/hooks"
import { AttributeType, BlockInfoAttribute, BlockInfoType, BlockType } from "@kameleon-core/types"
import { BlockAttributes } from "@wordpress/blocks"
import apiFetch from "@wordpress/api-fetch"
import { blocksRegisteredAction } from "../utils"
import { ManifestHelper } from "../manifest/manifest-helper"
import { WpBlock } from "./wp-block"
import { CustomPostType } from "../types/posts-helper"
import { registerHeaderFooterBlock } from "../redux/settings-store-helpers"

export type ExtendedBlockInfoAttribute = {
  innerBlockName?: string
  allowedBlocks?: string[]
  hidden?: boolean
} & BlockInfoAttribute

export type ExtendedBlockInfoAttributes = {
  [name: string]: ExtendedBlockInfoAttribute
}

export async function registerBlocks(): Promise<void> {
  try {
    const manifest = await ManifestHelper.getManifest()
    const kameleonBlocks = ManifestHelper.getAllBlocks(manifest)
    const allPrimaryBlocks = await fetchBlockInfoByType(BlockType.Primary)
    const allSecondaryBlocks = await fetchBlockInfoByType(BlockType.Secondary)
    const allTertiaryBlocks = await fetchBlockInfoByType(BlockType.Tertiary)
    const allSupportiveBlocks = [...allSecondaryBlocks, ...allTertiaryBlocks]

    const uniqueBlocks = Array.from(new Map(kameleonBlocks.map(block => [block.packageName, block])).values())

    const primaryBlockPromises = uniqueBlocks.map(async block => {
      const wpBlock = WpBlock.fromKameleonBlock(block)
      const blockInfo = allPrimaryBlocks.find(info => info.name === wpBlock.packageName)

      return wpBlock.register(blockInfo)
    })

    const supportiveBlockPromises = allSupportiveBlocks.map(async supportiveBlock => {
      const wpBlock = new WpBlock({
        name: WpBlock.packageToName(supportiveBlock.name),
        packageName: supportiveBlock.name,
      })

      return wpBlock.register(supportiveBlock)
    })

    const headerFooterPromises = [
      registerHeaderFooterBlock(CustomPostType.Header),
      registerHeaderFooterBlock(CustomPostType.Footer),
    ]

    await Promise.all([...primaryBlockPromises, ...supportiveBlockPromises, ...headerFooterPromises])

    doAction(blocksRegisteredAction)
  } catch (error) {
    // TODO: Error handling
  }
}

export async function fetchBlockInfoByPackageName(packageName: string): Promise<BlockInfoType> {
  return apiFetch<BlockInfoType>({ path: `/assistant/blockinfo/${packageName}`, method: "GET" })
}

export async function fetchBlockInfoByType(blockType: BlockType): Promise<BlockInfoType[]> {
  return apiFetch<BlockInfoType[]>({ path: `/assistant/blockinfo/type/${blockType}`, method: "GET" })
}

export function isInnerBlockAttribute(blockAttributeName: string): boolean {
  return blockAttributeName === "PrimaryBlocks"
}

export function isObjectInnerBlockAttribute(attribute: BlockInfoAttribute): boolean {
  return attribute.type === AttributeType.Object
}

export function isArrayInnerBlockAttribute(attribute: BlockInfoAttribute): boolean {
  return attribute.type === AttributeType.Array && attribute.items.type === AttributeType.Object
}

export function isFooterWidget(attributeName: string): boolean {
  return attributeName.toLowerCase() === "footerwidgets"
}

export function isSecondaryOrTertiary(attributeName?: string | undefined): boolean {
  return attributeName?.toLowerCase() === "secondaryblock" || attributeName?.toLowerCase() === "tertiaryblock"
}

export function isMediaArray(attribute: BlockInfoAttribute): boolean {
  return attribute.type === AttributeType.Array && attribute.items.type === AttributeType.Media
}

export function isMedia(attribute: BlockInfoAttribute, attributeValue: BlockAttributes): boolean {
  return attribute.type === AttributeType.Media && attributeValue && attributeValue.length > 0
}

export function isHeading(attribute: BlockInfoAttribute): boolean {
  return attribute.type === AttributeType.Heading
}

export function isButton(attribute: BlockInfoAttribute): boolean {
  return attribute.type === AttributeType.Button || attribute.type === AttributeType.Buttons
}
