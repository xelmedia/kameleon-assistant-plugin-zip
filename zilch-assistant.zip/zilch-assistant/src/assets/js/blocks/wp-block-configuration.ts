import { AttributeType, BlockInfoAttribute, BlockInfoType } from "@kameleon-core/types"
import { BlockAttributes, BlockConfiguration } from "@wordpress/blocks"
import { getBlockEdit } from "../components/block-edit"
import { ExtendedBlockInfoAttributes, isInnerBlockAttribute } from "."

type WpBlockConfigurationProps = {
  name: string
  title?: string
  type: AttributeType.Array | AttributeType.Object
  blockInfo: BlockInfoType
  blockInfoAttributes: ExtendedBlockInfoAttributes
}

// Extend the type to include custom properties
export interface CustomBlockConfiguration<T extends Record<string, any> = Record<string, any>>
  extends BlockConfiguration<T> {
  zilchBlockInfo?: BlockInfoType
}

export class WpBlockConfiguration {
  private name: string

  private type: AttributeType.Object | AttributeType.Array

  private blockInfo: BlockInfoType

  private blockInfoAttributes: ExtendedBlockInfoAttributes

  private title: string

  public constructor({ name, title, type, blockInfo, blockInfoAttributes }: WpBlockConfigurationProps) {
    this.name = name
    this.type = type
    this.blockInfo = blockInfo
    this.blockInfoAttributes = blockInfoAttributes
    this.title = title
  }

  public getConfiguration(): CustomBlockConfiguration<BlockAttributes> {
    return {
      apiVersion: 3,
      supports: {
        lock: false,
        inserter: ["Secondary", "Tertiary"].includes(this.blockInfo.blockType),
        reusable: false,
        multiple: true,
      },
      name: this.name,
      title: this.title,
      description: this.blockInfo.description,
      category: "common",
      icon: "layout",
      keywords: this.blockInfo.keywords,
      attributes: WpBlockConfiguration.getWpBlockAttributes(this.blockInfoAttributes),
      edit: getBlockEdit(this.name, this.blockInfo.blockType, this.blockInfoAttributes),
      save: () => null,
      zilchBlockInfo: this.blockInfo,
    }
  }

  public static getWpBlockAttributes(extendedAttributes: ExtendedBlockInfoAttributes): BlockAttributes {
    const blockInfo = Object.entries(extendedAttributes).reduce(
      (attrs, [name, attribute]: [string, BlockInfoAttribute]) => ({
        [name]: {
          ...WpBlockConfiguration.toWpBlockType(attribute.type, name),
        },
        ...attrs,
      }),
      {}
    )

    return blockInfo
  }

  private static toWpBlockType(type: AttributeType, name: string): any {
    if (isInnerBlockAttribute(name)) {
      return { type: "array" }
    }

    if (name === "inputs") {
      return { type: "string" }
    }

    switch (type) {
      case AttributeType.Text:
      case AttributeType.HTML:
      case AttributeType.Number:
        return { type: "string" }
      case AttributeType.Array:
        return { type: "array" }
      default:
        return { type: "object", attributes: {} }
    }
  }
}

export type ZilchBlock = ReturnType<WpBlockConfiguration["getConfiguration"]>
