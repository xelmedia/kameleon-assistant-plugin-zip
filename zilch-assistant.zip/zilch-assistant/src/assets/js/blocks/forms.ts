import apiFetch from "@wordpress/api-fetch"

export type FormOption = { label: string; value: string }

export async function fetchForms(): Promise<FormOption[]> {
  const response = await apiFetch({
    method: "GET",
    headers: {
      "Content-Type": "application/json",
    },
    url: "/?rest_route=/contact-form-7/v1/contact-forms",
    credentials: "include",
  })
  if (Array.isArray(response)) {
    return response.map((form: { title: string; id: number }) => ({
      label: form.title,
      value: form.id.toString(),
    }))
  }
  return []
}
