import { BlockInstance, rawHandler } from "@wordpress/blocks"
import { store as preferencesStore } from "@wordpress/preferences"
import { dispatch } from "@wordpress/data"

/**
 * Given the block content of a 'core/missing' block, try to parse the block again using rawHandler.
 * This should result in the creating of the correct block
 *
 * @param block
 */
function reloadBlock(block: BlockInstance): BlockInstance {
  if (block.name === "core/missing") {
    const html = block.attributes.originalContent || block.attributes.content
    const blocks = rawHandler({ HTML: html })
    return blocks[0]
  }
  return block
}

/**
 * Reload all blocks and set them in the block-editor
 * @param blocks
 */
export async function reloadAndRenderBlocks(blocks: BlockInstance[]): Promise<void> {
  const reloadedBlocks = blocks.map((block: BlockInstance) => reloadBlock(block))
  const { resetBlocks } = <any>dispatch("core/block-editor")

  await resetBlocks(reloadedBlocks)
}

export function disableWelcomeModal(): void {
  dispatch(preferencesStore).set("core/edit-post", "welcomeGuide", false)
}

/**
 * Alert manager for within the inline-block editor.
 */
type NoticeLevel = "info" | "success" | "warning" | "error"
type ZilchCookieNotice = { cookieName: string; noticeLevel: NoticeLevel }
const wpCookies = (): any => (<any>window)?.wpCookies

const noticeCookies: ZilchCookieNotice[] = [
  { cookieName: "zilch_gutenberg_error", noticeLevel: "warning" },
  { cookieName: "zilch_gutenberg_success", noticeLevel: "success" },
]

// Make sure initially the cookies are UNSET
export function deleteZilchGutenbergCookies(): void {
  noticeCookies.forEach(n => wpCookies().remove(n.cookieName))
}

export function checkZilchGutenbergAlerts(): void {
  noticeCookies.forEach(notice => {
    const cookieValue = wpCookies().get(notice.cookieName)
    if (cookieValue) {
      wpCookies().remove(notice.cookieName, "/")
      setGutenbergAlert(cookieValue, notice.noticeLevel)
    }
  })
}

export function hookBlockEditorNotices(): void {
  deleteZilchGutenbergCookies()

  // Override editor savePost function apply a "then", which will check for alerts/notices
  const editor = <any>dispatch("core/editor")
  const savePostFn = editor.savePost

  editor.savePost = (options = {}): void =>
    savePostFn(options).then(() => {
      checkZilchGutenbergAlerts()
    })
}

function setGutenbergAlert(msg: string, notice: NoticeLevel = "warning"): void {
  ;(<any>dispatch("core/notices")).removeAllNotices()
  ;(<any>dispatch("core/notices")).createNotice(notice, `${msg} (${new Date().toLocaleTimeString()})`, {
    __unstableHTML: true,
    isDismissible: true,
    actions: [],
  })
}
