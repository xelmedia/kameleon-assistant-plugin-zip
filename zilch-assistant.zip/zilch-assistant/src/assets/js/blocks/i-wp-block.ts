export interface IWpBlock {
  name: string
  register(): void
}
