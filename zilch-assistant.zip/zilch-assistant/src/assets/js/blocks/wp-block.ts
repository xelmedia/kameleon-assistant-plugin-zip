import { AttributeType, BlockInfoAttributes, BlockInfoType, BlockType } from "@kameleon-core/types"
import { IKameleonBlock } from "@kameleon-util/manifest"
import { getBlockType, registerBlockType } from "@wordpress/blocks"
import { ExtendedBlockInfoAttributes, fetchBlockInfoByPackageName } from "."
import { WpBlockConfiguration } from "./wp-block-configuration"
import { IWpBlock } from "./i-wp-block"

export type InnerBlockFromPackage = {
  attributeName: string
  packageName: string
  maxLength: number
}

type WpBlockProps = {
  name: string
  packageName: string
  sectionName?: string
  innerBlocks?: InnerBlockFromPackage[]
}

export class WpBlock implements IWpBlock {
  public readonly name: string

  packageName: string

  public sectionName?: string

  public innerBlocks: InnerBlockFromPackage[]

  public constructor({ name, packageName, sectionName, innerBlocks = [] }: WpBlockProps) {
    this.name = name
    this.packageName = packageName
    this.sectionName = sectionName
    this.innerBlocks = innerBlocks
  }

  public static fromKameleonBlock(block: IKameleonBlock): WpBlock {
    const innerBlocks: InnerBlockFromPackage[] = []

    return new WpBlock({
      name: WpBlock.formatName(block),
      packageName: block.packageName,
      sectionName: block.section,
      innerBlocks,
    })
  }

  public static formatName(block: IKameleonBlock): string {
    return `${block.packageName}`.replaceAll("@", "").toLowerCase()
  }

  public static packageToName(packageName: string): string {
    return `${packageName}`.replaceAll("@", "").toLowerCase()
  }

  public async register(blockInfoType?: BlockInfoType): Promise<void> {
    const blockType = getBlockType(this.name)
    if (blockType === undefined) {
      // only register the block if it has not been registered before
      let blockInfo: BlockInfoType = blockInfoType
      if (!blockInfo) {
        try {
          blockInfo = await fetchBlockInfoByPackageName(this.packageName)
        } catch (error) {
          const errorCode = error?.data?.status ?? error.code
          if ([404, "blockinfo_not_found", "404"].includes(errorCode)) {
            // console.error(`Block not found by name: ${this.packageName}, proceeding without registering this block.`)
            return
          }
          throw Error(`Error registering block: ${error.message}`)
        }
      }

      if (blockInfo.blockType === BlockType.Footer) {
        blockInfo.attributes.FooterWidgets = {
          type: AttributeType.Array,
          items: {
            type: AttributeType.Object,
            attributes: {},
          },
          maxLength: blockInfo.maxWidgets,
        }
      }

      const extendedAttributes = await WpBlock.getExtendedBlockInfoAttributes(blockInfo.attributes)

      const blockConfiguration = new WpBlockConfiguration({
        name: this.name,
        title: blockInfo.blockType === BlockType.Header ? this.sectionName : blockInfo.title,
        type: AttributeType.Object,
        blockInfo,
        blockInfoAttributes: extendedAttributes,
      }).getConfiguration()

      registerBlockType(this.name, blockConfiguration)
    }
  }

  /**
   * The BlockInfoAttributes object is extended with extra attributes section, sectionId and packageName.
   * For these attributes the hidden property is set to true so that these fields will not be shown in the block editor.
   * For innerBlock attributes the name of the innerBlock is added so that there is a reference to the innerBlock type.
   *
   *
   * @param attributes
   * @param innerBlocks
   * @param blockName
   */
  private static async getExtendedBlockInfoAttributes(
    attributes: BlockInfoAttributes
  ): Promise<ExtendedBlockInfoAttributes> {
    return Object.entries(attributes).reduce(
      (extendedAttributes, [attributeName, attribute]) => ({
        ...extendedAttributes,
        [attributeName]: {
          ...attribute,
        },
      }),
      {
        packageName: { type: AttributeType.Text, hidden: true },
        section: { type: AttributeType.Text, hidden: true },
        sectionId: { type: AttributeType.Text, hidden: true },
      } as ExtendedBlockInfoAttributes
    )
  }
}
