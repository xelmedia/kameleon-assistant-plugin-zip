import { ComponentType } from "react"

interface BlockToolsProps {
  children?: any
}

declare module "@types/wordpress__block-editor" {
  const BlockTools: ComponentType<BlockToolsProps>

  export { BlockTools }

  export * from "@types/wordpress__block-editor"
}
