export interface GetPostOptions {
  kameleon_page_id?: string
}

// eslint-disable-next-line no-shadow
export enum CustomPostType {
  "Header" = "zilch_header",
  "Footer" = "zilch_footer",
}

// eslint-disable-next-line no-shadow
export enum ZilchOptions {
  "Theme" = "zilch_theme",
  "Profile" = "zilch_profile",
  "Manifest" = "zilch_manifest_id",
}
