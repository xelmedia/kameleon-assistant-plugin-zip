import { EditorSettings } from "@wordpress/block-editor"

export interface ZilchEditorSettings extends EditorSettings {
  pluginUrl: string
}
