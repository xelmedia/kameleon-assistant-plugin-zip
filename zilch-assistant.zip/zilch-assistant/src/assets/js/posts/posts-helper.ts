import { Block, BlockInstance, createBlock, getBlockType, rawHandler, serialize } from "@wordpress/blocks"
import { IKameleonBlock } from "@kameleon-util/manifest"
import { Post } from "@wordpress/core-data"
import { getBaseUrl, getWpNonce } from "../utils"
import { WpBlock } from "../blocks/wp-block"
import { ManifestHelper } from "../manifest/manifest-helper"
import { CustomPostType, GetPostOptions } from "../types/posts-helper"
import { isSecondaryOrTertiary } from "../blocks"

const wpApi = (global.wp as any)?.api as any

/**
 * Converts raw HTML content to BlockInstances.
 * In case HTML content of a page, a list of BlockInstances may be returned.
 * @param content
 */
export const contentToBlockInstances = (content: string): BlockInstance[] => {
  // Load HTML string into a document to parse html dom tree
  const doc = new DOMParser().parseFromString(content, "text/html")
  const htmlBlocks: string[] = []
  for (const blockNode of <any>doc.body.children) {
    htmlBlocks.push(blockNode.outerHTML)
  }

  return htmlBlocks
    .filter(v => v && v.trim().length > 0)
    .map((HTML: string) => {
      try {
        return rawHandler({ HTML })
      } catch (e) {
        return [undefined]
      }
    })
    .flat()
    .filter(block => block !== undefined)
}

function findExistingBlocksBySectionId(existingBlocks: BlockInstance[], sectionId: string): BlockInstance[] {
  return existingBlocks.filter(blockInstance => blockInstance.attributes.sectionId === sectionId)
}

export function getAttributeValues(
  block: Block,
  existingBlock?: BlockInstance,
  previewProps?: Record<string, any>,
  kameleonBlock?: IKameleonBlock
): Record<string, any> {
  const attributeValues: any = {}
  Object.entries(block.attributes).forEach(([attributeName]) => {
    const existingBlockAttribute = existingBlock?.attributes?.[attributeName] !== undefined
    if (existingBlock && existingBlockAttribute) {
      attributeValues[attributeName] = existingBlock.attributes[attributeName]
    } else {
      const manifestProps = previewProps?.[attributeName] ?? null

      if (isSecondaryOrTertiary(attributeName) && manifestProps) {
        manifestProps.name = WpBlock.packageToName(manifestProps.packageName)
        manifestProps.attributes = manifestProps.blockProps
        delete manifestProps.blockProps
      }

      attributeValues[attributeName] = attributeName === "inputs" ? null : manifestProps
    }
  })

  if (kameleonBlock) {
    attributeValues.sectionId = kameleonBlock.sectionId
    attributeValues.section = kameleonBlock.section
    attributeValues.packageName = kameleonBlock.packageName
  }

  return attributeValues
}

// Create a helper function to convert Kameleon blocks to blocks, enforcing current attribute values (if present)
export const kameleonBlockToBlockInstance = (
  kameleonBlock: IKameleonBlock,
  existingBlockInstances: BlockInstance[]
): BlockInstance | undefined => {
  const blockName = WpBlock.formatName(kameleonBlock)
  const block = getBlockType(blockName)
  const existingBlock = findExistingBlocksBySectionId(existingBlockInstances, kameleonBlock.sectionId)?.[0]

  if (!block) {
    // Unable to find blockType for block layout: ${blockName}, proceeding with existing known data (when present)
    return undefined
  }

  return createBlockWithValuesAndInnerBlocks(block, existingBlock, kameleonBlock.previewProps, kameleonBlock)
}

function createBlockWithValuesAndInnerBlocks(
  block: Block,
  existingBlock?: BlockInstance,
  previewProps?: Record<string, any>,
  kameleonBlock?: IKameleonBlock,
  noValues = false
): BlockInstance {
  const attributeValues = noValues ? {} : getAttributeValues(block, existingBlock, previewProps, kameleonBlock)

  return createBlock(block.name, attributeValues, [])
}

export function getPostContent(wpBlockName: string): string {
  const blockInstance = createBlock(wpBlockName, {})
  return serialize([blockInstance])
}

export async function getExistingPosts(postType: string, options: GetPostOptions): Promise<Post[] | undefined> {
  const library = new wpApi.models.Post()
  library?.endpointModel?.set("nonce", getWpNonce())
  const result = await library.fetch({
    url: `${getBaseUrl()}/?rest_route=/assistant/posts/${postType}`,
    data: options,
  })
  return result?.length > 0 ? result : undefined
}

export async function getAndRegisterWpBlockByPostType(postType: CustomPostType): Promise<WpBlock> {
  const manifest = await ManifestHelper.getManifest()
  let wpBlock: WpBlock

  if (postType === CustomPostType.Header) {
    wpBlock = WpBlock.fromKameleonBlock(manifest.getHeader())
    wpBlock.sectionName = "Header"
  } else if (postType === CustomPostType.Footer) {
    const footer = manifest.getFooter()

    wpBlock = WpBlock.fromKameleonBlock(footer)
    wpBlock.sectionName = "Footer"
  } else {
    throw Error(`unknown custom post type: ${postType}`)
  }
  await wpBlock.register()
  return wpBlock
}
