import { IKameleonBlock, ManifestAPI, ManifestHelper as ManifestHelperUtil } from "@kameleon-util/manifest"
import apiFetch from "@wordpress/api-fetch"
import { getBaseUrl } from "../utils"

export class ManifestHelper {
  private static manifestAPI: ManifestAPI | undefined = undefined

  private static readonly maxGetManifestRetry = 3

  /**
   * Resolve manifest with delayed retry. Sometimes a race-condition occurs, of which the nonce was not yet set.
   * Retrying might resolve this issue.
   * @param retry
   */
  public static async getManifest(retry = 0): Promise<ManifestAPI | undefined> {
    return ManifestHelper.resolveManifest().catch(async e => {
      if (retry >= this.maxGetManifestRetry) {
        throw e
      }

      // console.warn(`Resolving manifest failed, retry ${retry + 1}`)
      await new Promise(f => {
        setTimeout(f, 1000)
      })
      return this.getManifest(retry + 1)
    })
  }

  /**
   * Retreive the manifest from local storage. If not exist, get from API
   */
  public static async loadManifest(): Promise<ManifestAPI | undefined> {
    const manifest = localStorage.getItem("zilchManifest")
    if (!manifest) {
      return this.getManifest()
    }
    ManifestHelper.manifestAPI = ManifestHelperUtil.from(JSON.parse(manifest))
    return Promise.resolve(ManifestHelper.manifestAPI)
  }

  private static async resolveManifest(): Promise<ManifestAPI | undefined> {
    if (!ManifestHelper.manifestAPI) {
      const url = `${getBaseUrl()}/?rest_route=/assistant/get-manifest`
      const response: any = await apiFetch({ url })
      ManifestHelper.manifestAPI = ManifestHelperUtil.from(response)

      localStorage.setItem("zilchManifest", JSON.stringify(response))

      return ManifestHelper.manifestAPI
    }
    return ManifestHelper.manifestAPI
  }

  static getAllBlocks(manifestAPI: ManifestAPI): IKameleonBlock[] {
    return manifestAPI
      .getPages()
      .map(page => page.blocks)
      .flat()
  }
}
