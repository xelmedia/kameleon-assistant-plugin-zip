import { addAction } from "@wordpress/hooks"
import { register } from "@wordpress/data"
import { registerPages, renderLoadingPages } from "./pages/register-pages"
import { blocksRegisteredAction, blocksRegisteredNamespace } from "./utils"
import { settingStore } from "./redux/settings-store"

renderLoadingPages()

addAction(blocksRegisteredAction, blocksRegisteredNamespace, async () => {
  register(settingStore)

  await registerPages()
})
